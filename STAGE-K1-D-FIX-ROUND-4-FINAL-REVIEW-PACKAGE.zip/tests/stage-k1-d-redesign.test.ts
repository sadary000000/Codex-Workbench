import assert from "node:assert/strict";
import { mkdtemp, rm } from "node:fs/promises";
import { join } from "node:path";
import { tmpdir } from "node:os";
import test from "node:test";
import {
  AutomationStore,
  buildPlannerProviderRequest,
  canonicalize,
  FINAL_PLANNER_RESULT_BEGIN,
  FINAL_PLANNER_RESULT_END,
  MAX_PLANNER_RESULT_ENVELOPE_BYTES,
  PlannerResultEnvelopeError,
  createPlannerProviderIntegrationService,
  isKnownPlannerProviderErrorResponse,
  parsePlannerResultEnvelope,
  policyVersionPayload,
  type PlanCandidate,
  type ProviderCapabilityFact,
  type ProviderCorrelation,
  type ProviderObservation,
  type ProviderRequestAccepted,
  type ProviderResult,
  type ProviderSubmitInput,
  type ProviderTargetResolution,
} from "../src/automation/index.ts";

const PROJECT_ID = "k1-d-redesign-project";
const TARGET = "fake:planner:k1-d";

function plannerCandidate(requirementVersionId: string, requirementPayloadSha256: string, planVersionId: string): PlanCandidate {
  return {
    planVersionId,
    projectId: PROJECT_ID,
    requirementVersionId,
    requirementPayloadSha256,
    version: 1,
    supersedes: null,
    currentStageId: "stage-k1-d-current",
    stages: [{
      stageSpecId: "stage-k1-d-current",
      stageKey: "CURRENT",
      name: "Current bounded stage",
      objective: "Define the bounded current planning stage.",
      dependsOn: [],
      acceptanceCriteria: ["The current stage has an explicit acceptance boundary."],
      detailLevel: "DETAILED",
      assumptions: [],
      risks: [],
      specVersion: 1,
      ordinal: 0,
      supersedes: null,
    }],
    steps: [{
      stepSpecId: "step-k1-d-current",
      stageSpecId: "stage-k1-d-current",
      stepKey: "DEFINE_BOUNDARY",
      specVersion: 1,
      kind: "PLANNER_STEP",
      ordinal: 0,
      objective: "Define the bounded implementation step.",
      inputs: ["confirmed requirement reference"],
      expectedOutputs: ["bounded stage definition"],
      acceptanceCriteria: ["The stage definition is explicit and reviewable."],
      assumptions: [],
      constraints: ["Do not execute a step during planning."],
      riskClass: "LOW",
      sideEffectClass: "PURE",
      supersedes: null,
    }],
    ambiguity: { blockingQuestions: [], missingRequirementFields: [], assumptions: [] },
  };
}

function envelope(candidate: PlanCandidate): string {
  return `${FINAL_PLANNER_RESULT_BEGIN}\n${JSON.stringify({ schemaVersion: 1, ...candidate })}\n${FINAL_PLANNER_RESULT_END}`;
}

class FakePlannerProvider {
  readonly provider = "FAKE_PLANNER";
  readonly submitted: ProviderSubmitInput[] = [];
  observeCount = 0;
  reconcileCount = 0;
  mode: "COMPLETED" | "UNKNOWN" | "FAILED" = "COMPLETED";
  responses: unknown[] = [];
  recoveredRequestRef: string | null = null;

  async resolveTarget(input: { workflowRole: string | null; providerTargetRef: string }): Promise<ProviderTargetResolution> {
    return { provider: this.provider, workflowRole: input.workflowRole, providerTargetRef: input.providerTargetRef, status: "AVAILABLE", capability: "AVAILABLE" };
  }

  async capabilities(): Promise<readonly ProviderCapabilityFact[]> {
    return [{ provider: this.provider, code: "AVAILABLE" }];
  }

  async submit(input: ProviderSubmitInput): Promise<ProviderRequestAccepted> {
    this.submitted.push(input);
    const policyVersionId = input.correlation.policyVersionId!;
    const correlationId = input.correlation.idempotencyRef!;
    const effectivePolicy = {
      decision: "ALLOW" as const,
      effectivePolicy: {
        policyVersionId,
        projectId: input.correlation.projectId,
        runtimeCapabilityVersion: "fake-capability-v1",
        runtimeId: "fake-runtime",
        pin: { policyVersionId, projectId: input.correlation.projectId, version: 1, correlationId, pinnedAt: "2026-01-01T00:00:00.000Z" },
      },
      evidence: { policyVersionId, effectiveDecision: "ALLOW" as const },
    };
    return {
      provider: this.provider,
      providerRequestRef: `planner-attempt-${this.submitted.length}`,
      providerTargetRef: input.providerTargetRef,
      semanticRef: `provider-semantic-${this.submitted.length}`,
      policy: {
        policyVersionId,
        operation: "SUBMIT",
        decision: "ALLOW",
        runtimeCapabilityVersion: "fake-capability-v1",
        runtimeId: "fake-runtime",
        actionAttemptId: input.correlation.actionAttemptId!,
        effectivePolicy,
      } as ProviderRequestAccepted["policy"],
    };
  }

  async observe(input: { providerRequestRef: string; correlation?: ProviderCorrelation }): Promise<ProviderObservation> {
    this.observeCount += 1;
    const number = Number(input.providerRequestRef.split("-").at(-1) ?? "1");
    const submitted = this.submitted[number - 1];
    const state = this.mode;
    return {
      provider: this.provider,
      providerRequestRef: input.providerRequestRef,
      providerTargetRef: submitted?.providerTargetRef ?? TARGET,
      semanticRef: input.correlation?.providerSemanticRef ?? `provider-semantic-${number}`,
      state,
      outcomeCertainty: state === "COMPLETED" ? "TERMINAL_CONFIRMED" : state === "FAILED" ? "TERMINAL_FAILED" : "ACCEPTED_UNKNOWN_RESULT",
      resultRef: state === "COMPLETED" ? `result:${input.providerRequestRef}` : null,
      resultHash: null,
      evidenceRefs: [],
    };
  }

  async reconcile(input: { providerRequestRef: string; correlation: ProviderCorrelation }): Promise<ProviderObservation> {
    this.reconcileCount += 1;
    return this.observe(input);
  }

  async resolveRequestByCorrelation(): Promise<string | null> {
    return this.recoveredRequestRef;
  }

  async readResult(input: { providerRequestRef: string }): Promise<ProviderResult> {
    const number = Number(input.providerRequestRef.split("-").at(-1) ?? "1");
    return {
      provider: this.provider,
      providerRequestRef: input.providerRequestRef,
      state: "COMPLETED",
      response: (this.responses[number - 1] ?? "") as string,
      resultHash: null,
    };
  }
}

async function fixture() {
  const root = await mkdtemp(join(tmpdir(), "codex-k1-d-redesign-"));
  const store = new AutomationStore(join(root, "automation.db"));
  await store.createAutomationProject({ projectId: PROJECT_ID, name: "K1-D redesign" });
  await store.createPolicyVersion({
    policyVersionId: "policy-k1-d-1",
    projectId: PROJECT_ID,
    version: 1,
    preset: "k1-d-test",
    payload: policyVersionPayload({ maxPromptDispatches: 5, maxRepairDispatches: 2, maxRetryDispatches: 2, maxNewChatDispatches: 1, allowedOperations: ["PROMPT", "REPAIR", "RETRY", "NEW_CHAT"], requireHumanGateFor: [], allowDataEgress: false, allowSideEffects: false }),
    supersedes: null,
  });
  const requirement = await store.createRequirementVersion({
    projectId: PROJECT_ID,
    requirementVersionId: "requirement-k1-d-1",
    version: 1,
    status: "CONFIRMED",
    origin: { originType: "INITIAL", source: "SYSTEM", sourceRef: "test:k1-d" },
    canonicalPayload: JSON.stringify({ goal: "Prove bounded Planner retry and promotion." }),
  });
  return { root, store, requirement };
}

async function dispose(value: Awaited<ReturnType<typeof fixture>>, extraStores: AutomationStore[] = []) {
  for (const store of extraStores) await store.close();
  await value.store.close();
  await rm(value.root, { recursive: true, force: true });
}

test("K1-D envelope is exact, bounded, and does not repair or extract JSON", () => {
  const valid = `${FINAL_PLANNER_RESULT_BEGIN}\n${JSON.stringify({ schemaVersion: 1, value: "ok" })}\n${FINAL_PLANNER_RESULT_END}`;
  assert.deepEqual(parsePlannerResultEnvelope(valid).result, { value: "ok" });
  for (const invalid of [
    "{\"schemaVersion\":1}",
    `${FINAL_PLANNER_RESULT_BEGIN}\n${JSON.stringify({ schemaVersion: 1, value: "ok" })}`,
    `${FINAL_PLANNER_RESULT_BEGIN}\n{"schemaVersion":1,"value":}\n${FINAL_PLANNER_RESULT_END}`,
    `${FINAL_PLANNER_RESULT_BEGIN}\n{"schemaVersion":1,"value":"ok","value":"drift"}\n${FINAL_PLANNER_RESULT_END}`,
    FINAL_PLANNER_RESULT_BEGIN + "\n```json\n{\"schemaVersion\":1,\"value\":\"ok\"}\n```\n" + FINAL_PLANNER_RESULT_END,
    `prose\n${valid}`,
    `${valid}\nprose`,
  ]) {
    assert.throws(() => parsePlannerResultEnvelope(invalid), PlannerResultEnvelopeError);
  }
  assert.throws(() => parsePlannerResultEnvelope(`${FINAL_PLANNER_RESULT_BEGIN}\n${"x".repeat(MAX_PLANNER_RESULT_ENVELOPE_BYTES)}\n${FINAL_PLANNER_RESULT_END}`), PlannerResultEnvelopeError);
  assert.equal(isKnownPlannerProviderErrorResponse("Something went wrong while generating the response.\n\n重试"), true);
  assert.equal(isKnownPlannerProviderErrorResponse("Something went wrong while generating the response. If this issue persists please contact us through our help center at help.openai.com.\n\n重试"), true);
  assert.equal(isKnownPlannerProviderErrorResponse("Something went wrong while generating the response.\n重试"), false);
  assert.equal(isKnownPlannerProviderErrorResponse(`Something went wrong while generating the response.\n\n重试${"x".repeat(MAX_PLANNER_RESULT_ENVELOPE_BYTES)}`), false);
});

test("K1-D keeps one logical request, creates only Attempt #2, and promotes at most once", async () => {
  const value = await fixture();
  const provider = new FakePlannerProvider();
  provider.responses = ["not-an-envelope", envelope(plannerCandidate(value.requirement.requirementVersionId, value.requirement.payloadSha256, "plan-k1-d-1"))];
  try {
    const service = createPlannerProviderIntegrationService({ store: value.store, provider });
    const first = await service.createPlanFromRequirement({ projectId: PROJECT_ID, providerTargetRef: TARGET });
    assert.equal(first.status, "INVALID_PROVIDER_RESULT");
    const afterFirst = await value.store.snapshot();
    const intent = afterFirst.actionIntents.find((item) => item.actionType === "PLANNER_REQUEST");
    assert.ok(intent);
    assert.equal(afterFirst.actionIntents.length, 1);
    assert.equal(afterFirst.actionAttempts.length, 1);
    assert.equal(afterFirst.actionAttempts[0]?.attemptNumber, 1);
    assert.equal(afterFirst.actionAttempts[0]?.logicalPlannerRequestId, intent.logicalPlannerRequestId);
    assert.equal(afterFirst.actionAttempts[0]?.plannerResultClassification, "INVALID_OUTPUT_RETRYABLE");
    assert.equal(afterFirst.actionReceipts[0]?.status, "SUCCEEDED");
    assert.equal(afterFirst.planVersions.length, 0);

    await assert.rejects(() => value.store.transitionActionIntent(intent.intentId, "REAUTHORIZE_RETRY"), { code: "AUTOMATION_CONFLICT" });
    const second = await service.retryPlannerRequest({ projectId: PROJECT_ID, actionIntentId: intent.intentId });
    assert.equal(second.status, "PLAN_READY");
    assert.equal(provider.submitted.length, 2);
    assert.equal(provider.submitted[0]?.correlation.idempotencyRef, provider.submitted[1]?.correlation.idempotencyRef);
    assert.notEqual(provider.submitted[0]?.correlation.providerAttemptIdempotencyRef, provider.submitted[1]?.correlation.providerAttemptIdempotencyRef);
    assert.notEqual(provider.submitted[0]?.correlation.actionAttemptId, provider.submitted[1]?.correlation.actionAttemptId);

    const afterSecond = await value.store.snapshot();
    const attempts = afterSecond.actionAttempts.filter((item) => item.intentId === intent.intentId).sort((left, right) => (left.attemptNumber ?? 0) - (right.attemptNumber ?? 0));
    assert.equal(afterSecond.actionIntents.length, 1);
    assert.equal(attempts.length, 2);
    assert.deepEqual(attempts.map((item) => item.attemptNumber), [1, 2]);
    assert.equal(attempts[1]?.plannerResultClassification, "VALID_OUTPUT");
    assert.equal(afterSecond.planVersions.length, 1);
    assert.equal(afterSecond.automationProjects[0]?.activePlanVersionId, second.planVersion?.planVersionId);
    assert.equal(afterSecond.auditEvents.filter((event) => event.eventType === "PLANNER_PLAN_PROMOTED").length, 1);
    assert.equal(afterSecond.requirementVersions.length, 1);
    assert.equal(afterSecond.actionIntents.filter((item) => item.actionType !== "PLANNER_REQUEST").length, 0);
    await assert.rejects(() => service.retryPlannerRequest({ projectId: PROJECT_ID, actionIntentId: intent.intentId }), { code: "AUTOMATION_CONFLICT" });
    assert.equal(provider.submitted.length, 2, "Attempt #3 must never be dispatched");
  } finally {
    await dispose(value);
  }
});

test("K1-D rejects UNKNOWN retry and reconciles the same ProviderAttempt", async () => {
  const value = await fixture();
  const provider = new FakePlannerProvider();
  provider.mode = "UNKNOWN";
  provider.responses = [envelope(plannerCandidate(value.requirement.requirementVersionId, value.requirement.payloadSha256, "plan-k1-d-unknown"))];
  try {
    const service = createPlannerProviderIntegrationService({ store: value.store, provider });
    const first = await service.createPlanFromRequirement({ projectId: PROJECT_ID, providerTargetRef: TARGET });
    assert.equal(first.status, "RECOVERY_REQUIRED");
    const snapshot = await value.store.snapshot();
    const intent = snapshot.actionIntents[0]!;
    const attempt = snapshot.actionAttempts[0]!;
    assert.equal(attempt.plannerResultClassification, "UNKNOWN_AFTER_SIDE_EFFECT");
    assert.equal(snapshot.actionReceipts[0]?.status, "UNKNOWN");
    await assert.rejects(() => service.retryPlannerRequest({ projectId: PROJECT_ID, actionIntentId: intent.intentId }), { code: "AUTOMATION_CONFLICT" });
    assert.equal(provider.submitted.length, 1);
    provider.mode = "COMPLETED";
    const reconciled = await service.reconcilePlannerRequest({ projectId: PROJECT_ID, actionAttemptId: attempt.actionAttemptId });
    assert.equal(reconciled.status, "PLAN_READY");
    assert.equal(provider.submitted.length, 1, "reconcile must not resubmit the logical request");
    assert.equal(provider.reconcileCount, 1);
    const final = await value.store.snapshot();
    assert.equal(final.actionAttempts.length, 1);
    assert.equal(final.actionAttempts[0]?.plannerResultClassification, "VALID_OUTPUT");
    assert.equal(final.planVersions.length, 1);
  } finally {
    await dispose(value);
  }
});

test("K1-D reattaches a missing ProviderRequest after restart without creating an attempt", async () => {
  const value = await fixture();
  const provider = new FakePlannerProvider();
  provider.mode = "COMPLETED";
  provider.responses = [envelope(plannerCandidate(value.requirement.requirementVersionId, value.requirement.payloadSha256, "plan-k1-d-restart"))];
  try {
    const service = createPlannerProviderIntegrationService({ store: value.store, provider });
    const inputRef = `automation-input-v1:${"a".repeat(64)}`;
    const request = buildPlannerProviderRequest({
      projectId: PROJECT_ID,
      requirement: value.requirement,
      providerTargetRef: TARGET,
      operation: "PLAN_REQUIREMENT",
      planningConstraints: ["planning-only"],
      inputRefs: [inputRef],
    });
    const intent = await value.store.createActionIntent({
      projectId: PROJECT_ID,
      actionType: "PLANNER_REQUEST",
      targetRef: TARGET,
      sideEffectClass: "RECONCILABLE",
      payloadRef: inputRef,
      executionOptions: { plannerOperation: request.operation, requirementVersionId: request.requirementVersionId, requirementPayloadSha256: request.requirementPayloadSha256 },
      plannerRequestCanonical: canonicalize(request, "planner.request"),
      plannerRequirementVersionId: request.requirementVersionId,
      plannerRequirementPayloadSha256: request.requirementPayloadSha256,
      plannerOperation: request.operation,
      plannerMaxProviderAttempts: 2,
      logicalPlannerRequestId: "restart-logical-k1-d",
      idempotencyRef: "restart-idempotency-k1-d",
      expectedOutcomeRef: "restart-idempotency-k1-d",
      policyVersionId: "policy-k1-d-1",
    });
    await value.store.markActionIntentDispatchEligible(intent.intentId, { actorType: "AUTOMATION", correlationId: intent.intentId });
    const attempt = await value.store.createActionAttempt({ intentId: intent.intentId, policyVersionId: intent.policyVersionId, executorRef: "automation.planner-provider" });
    provider.recoveredRequestRef = "planner-attempt-1";
    const recovered = await service.reconcilePlannerRequest({ projectId: PROJECT_ID, actionAttemptId: attempt.actionAttemptId });
    assert.equal(recovered.status, "PLAN_READY");
    assert.equal(provider.submitted.length, 0);
    assert.equal(provider.reconcileCount, 1);
    const after = await value.store.snapshot();
    assert.equal(after.actionAttempts.length, 1);
    const recoveredExternalRef = after.externalRefs.find((item) => item.kind === "WEBGPT_PROVIDER_REQUEST" && item.opaqueId === "planner-attempt-1");
    assert.ok(recoveredExternalRef);
    assert.equal(after.actionAttempts[0]?.providerRequestRef, recoveredExternalRef.externalRefId);
    assert.equal(after.planVersions.length, 1);
  } finally {
    await dispose(value);
  }
});

test("K1-D historical Attempt #1 binding requires the exact logical descriptor and source InputRef", async () => {
  const value = await fixture();
  try {
    const currentInputRef = `automation-input-v1:${"a".repeat(64)}`;
    const historicalInputRef = `automation-input-v1:${"b".repeat(64)}`;
    const currentRequest = buildPlannerProviderRequest({
      projectId: PROJECT_ID,
      requirement: value.requirement,
      providerTargetRef: TARGET,
      operation: "PLAN_REQUIREMENT",
      planningConstraints: ["planning-only"],
      inputRefs: [currentInputRef],
    });
    const historicalRequest = buildPlannerProviderRequest({
      projectId: PROJECT_ID,
      requirement: value.requirement,
      providerTargetRef: TARGET,
      operation: "PLAN_REQUIREMENT",
      planningConstraints: ["planning-only"],
      inputRefs: [historicalInputRef],
    });
    const intent = await value.store.createActionIntent({
      intentId: "logical-historical-k1-d",
      projectId: PROJECT_ID,
      actionType: "PLANNER_REQUEST",
      targetRef: TARGET,
      sideEffectClass: "RECONCILABLE",
      payloadRef: currentInputRef,
      executionOptions: {
        plannerOperation: currentRequest.operation,
        requirementVersionId: currentRequest.requirementVersionId,
        requirementPayloadSha256: currentRequest.requirementPayloadSha256,
      },
      plannerRequestCanonical: canonicalize(currentRequest, "planner.request"),
      plannerRequirementVersionId: currentRequest.requirementVersionId,
      plannerRequirementPayloadSha256: currentRequest.requirementPayloadSha256,
      plannerOperation: currentRequest.operation,
      plannerMaxProviderAttempts: 2,
      logicalPlannerRequestId: "logical-historical-k1-d",
      idempotencyRef: "historical-idempotency-k1-d",
      expectedOutcomeRef: "historical-idempotency-k1-d",
      policyVersionId: "policy-k1-d-1",
    });
    await value.store.markActionIntentDispatchEligible(intent.intentId, { actorType: "AUTOMATION", correlationId: intent.intentId });
    const bindInput = {
      projectId: PROJECT_ID,
      actionIntentId: intent.intentId,
      logicalPlannerRequestId: intent.logicalPlannerRequestId!,
      actionAttemptId: "historical-attempt-k1-d",
      provider: "FAKE_PLANNER",
      providerRequestRef: "historical-provider-request-k1-d",
      historicalPlannerRequestCanonical: canonicalize(historicalRequest, "historicalAttempt.plannerRequestCanonical"),
      sourceIdempotencyRef: "historical-idempotency-k1-d",
      sourceInputRef: historicalInputRef,
      sourceInputSha256: "b".repeat(64),
      sourceInputLength: 12,
      sourceCreatedAt: "2026-08-27T00:00:00.000Z",
      sourceStartedAt: "2026-08-27T00:00:01.000Z",
      sourceCompletedAt: "2026-08-27T00:00:02.000Z",
      sourceResultSha256: "c".repeat(64),
    } as const;
    const mismatch = { ...historicalRequest, providerTargetRef: "fake:other-target" };
    await assert.rejects(() => value.store.bindHistoricalPlannerAttempt({ ...bindInput, historicalPlannerRequestCanonical: canonicalize(mismatch, "historicalAttempt.plannerRequestCanonical") }), { code: "AUTOMATION_CONFLICT" });
    const bound = await value.store.bindHistoricalPlannerAttempt(bindInput);
    assert.equal(bound.attempt.attemptNumber, 1);
    assert.equal(bound.attempt.plannerResultClassification, "INVALID_OUTPUT_RETRYABLE");
    assert.equal(bound.receipt.status, "SUCCEEDED");
    assert.equal((await value.store.snapshot()).actionAttempts.length, 1);
  } finally {
    await dispose(value);
  }
});

test("K1-D serializes retry authorization across two Store handles", async () => {
  const value = await fixture();
  const provider = new FakePlannerProvider();
  provider.responses = ["not-an-envelope", envelope(plannerCandidate(value.requirement.requirementVersionId, value.requirement.payloadSha256, "plan-k1-d-concurrent"))];
  const secondStore = new AutomationStore(join(value.root, "automation.db"));
  try {
    const service1 = createPlannerProviderIntegrationService({ store: value.store, provider });
    const first = await service1.createPlanFromRequirement({ projectId: PROJECT_ID, providerTargetRef: TARGET });
    const intentId = first.actionIntentId!;
    const service2 = createPlannerProviderIntegrationService({ store: secondStore, provider });
    const results = await Promise.allSettled([
      service1.retryPlannerRequest({ projectId: PROJECT_ID, actionIntentId: intentId }),
      service2.retryPlannerRequest({ projectId: PROJECT_ID, actionIntentId: intentId }),
    ]);
    assert.equal(results.filter((result) => result.status === "fulfilled").length, 1);
    assert.equal(results.filter((result) => result.status === "rejected").length, 1);
    const final = await value.store.snapshot();
    assert.equal(final.actionIntents.length, 1);
    assert.equal(final.actionAttempts.length, 2);
    assert.equal(provider.submitted.length, 2);
    assert.equal(final.planVersions.length, 1);
  } finally {
    await dispose(value, [secondStore]);
  }
});
