import assert from "node:assert/strict";
import { test } from "node:test";
import { assessStageK1DProvenance } from "../src/automation/stage-k1-d-provenance.ts";
import { WEBGPT_PAGE_PROBE_SCRIPT } from "../src/features/webgpt/adapter/webgpt-page-adapter.ts";
import { isWebGptPageProbeBoundaryCurrent, isWebGptTargetEpochCurrent, targetEpochMismatchFields, type WebGptTargetReadinessEpoch } from "../src/features/webgpt/runtime/webgpt-target-epoch.ts";

function epoch(): WebGptTargetReadinessEpoch {
  return {
    epochId: 4,
    navigationEpoch: 8,
    pageStateRevision: 12,
    controlEpoch: 3,
    operationId: "operation-1",
    observerEpoch: 5,
    expectedChatUrl: "https://chatgpt.com/c/target",
  };
}

test("K1-D target readiness accepts only one unchanged atomic epoch", () => {
  const boundary = epoch();
  assert.equal(isWebGptTargetEpochCurrent(boundary, {
    navigationEpoch: 8,
    pageStateRevision: 12,
    controlEpoch: 3,
    observerEpoch: 5,
  }), true);
});

test("late navigation cannot satisfy a newer target dispatch epoch", () => {
  const mismatches = targetEpochMismatchFields(epoch(), {
    navigationEpoch: 9,
    pageStateRevision: 13,
    controlEpoch: 3,
    observerEpoch: 6,
  });
  assert.deepEqual(mismatches, ["navigationEpoch", "pageStateRevision", "observerEpoch"]);
  assert.equal(isWebGptTargetEpochCurrent(epoch(), {
    navigationEpoch: 9,
    pageStateRevision: 13,
    controlEpoch: 3,
    observerEpoch: 6,
  }), false);
});

test("control takeover and observer epoch changes are independently fail-closed", () => {
  assert.deepEqual(targetEpochMismatchFields(epoch(), {
    navigationEpoch: 8,
    pageStateRevision: 12,
    controlEpoch: 4,
    observerEpoch: 5,
  }), ["controlEpoch"]);
  assert.deepEqual(targetEpochMismatchFields(epoch(), {
    navigationEpoch: 8,
    pageStateRevision: 12,
    controlEpoch: 3,
    observerEpoch: 6,
  }), ["observerEpoch"]);
});

test("a late Page Probe timeout cannot invalidate a newer target boundary", () => {
  const oldProbe = { navigationEpoch: 8, pageStateRevision: 12, targetEpochId: 4 } as const;
  assert.equal(isWebGptPageProbeBoundaryCurrent(oldProbe, oldProbe), true);
  assert.equal(isWebGptPageProbeBoundaryCurrent(oldProbe, {
    navigationEpoch: 9,
    pageStateRevision: 13,
    targetEpochId: 5,
  }), false);
});

test("the page probe contract never treats a generic home Composer as Chat identity", () => {
  assert.doesNotMatch(WEBGPT_PAGE_PROBE_SCRIPT, /onChatPage = [^;]*\|\| Boolean\(composer\)/);
  assert.ok(WEBGPT_PAGE_PROBE_SCRIPT.includes("const onChatPage = /(?:^|\\/)c\\/[^/]+(?:\\/|$)/.test(location.pathname);"));
});

function manifest(executable = "exe-hash", runner = "runner-hash"): Record<string, unknown> {
  return {
    source_commit: "c19059b625807dff3c77b100585821476a88bf87",
    worktree_state: "dirty",
    worktree_state_sha256: "tree-state-hash",
    source_tree_sha256: "source-tree-hash",
    build_timestamp: "2026-08-27T12:00:00.000Z",
    package_timestamp: "2026-08-27T12:01:00.000Z",
    executable_sha256: executable,
    runner_script_sha256: runner,
  };
}

test("K1-D provenance accepts a matching packaged executable and runner", () => {
  const result = assessStageK1DProvenance({
    manifest: manifest(),
    executablePath: "dist/package/Codex Workbench V1.exe",
    executableSha256: "exe-hash",
    runnerScriptSha256: "runner-hash",
  });
  assert.equal(result.verified, true);
  assert.deepEqual(result.verification_errors, []);
});

test("K1-D provenance mismatch cannot be promoted to a verified smoke", () => {
  const result = assessStageK1DProvenance({
    manifest: manifest(),
    executablePath: "dist/package/Codex Workbench V1.exe",
    executableSha256: "mutated-exe",
    runnerScriptSha256: "mutated-runner",
  });
  assert.equal(result.verified, false);
  assert.deepEqual(result.verification_errors, ["EXECUTABLE_HASH_MISMATCH", "RUNNER_HASH_MISMATCH"]);
});

test("missing package provenance is not inferred from a live executable", () => {
  const result = assessStageK1DProvenance({
    manifest: null,
    executablePath: "dist/package/Codex Workbench V1.exe",
    executableSha256: "exe-hash",
    runnerScriptSha256: "runner-hash",
  });
  assert.equal(result.verified, false);
  assert.ok(result.verification_errors.includes("PACKAGE_PROVENANCE_MANIFEST_MISSING"));
});
