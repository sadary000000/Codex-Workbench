import { cp, mkdir, readFile, readdir, rm, stat, writeFile } from "node:fs/promises";
import { createHash } from "node:crypto";
import { join, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import { execFileSync } from "node:child_process";

const projectRoot = resolve(fileURLToPath(new URL("..", import.meta.url)));
const tsc = join(projectRoot, "node_modules", "typescript", "bin", "tsc");
const distRoot = resolve(process.env.CODEX_WORKBENCH_DIST ?? join(projectRoot, "dist"));

function sha256(value) {
  return createHash("sha256").update(value).digest("hex");
}

function git(args) {
  try {
    return execFileSync("git", args, { cwd: projectRoot, encoding: "utf8" }).trim();
  } catch {
    return null;
  }
}

async function fileEntries(root, prefix = "") {
  const entries = [];
  for (const entry of (await readdir(root, { withFileTypes: true })).sort((left, right) => left.name.localeCompare(right.name))) {
    const relativePath = prefix ? `${prefix}/${entry.name}` : entry.name;
    const absolutePath = join(root, entry.name);
    if (entry.isDirectory()) entries.push(...await fileEntries(absolutePath, relativePath));
    else if (entry.isFile()) {
      const bytes = await readFile(absolutePath);
      entries.push(`${relativePath}\0${sha256(bytes)}\n`);
    }
  }
  return entries;
}

async function sourceTreeSha256() {
  const entries = [];
  for (const relativePath of ["src", "scripts", "package.json", "tsconfig.json", "tsconfig.tests.json"]) {
    const absolutePath = join(projectRoot, relativePath);
    const metadata = await stat(absolutePath);
    if (metadata.isDirectory()) entries.push(...await fileEntries(absolutePath, relativePath));
    else entries.push(`${relativePath}\0${sha256(await readFile(absolutePath))}\n`);
  }
  return sha256(entries.sort().join(""));
}

await rm(distRoot, { recursive: true, force: true });
execFileSync(process.execPath, [tsc, "-p", join(projectRoot, "tsconfig.json"), "--outDir", distRoot], {
  cwd: projectRoot,
  stdio: "inherit",
});
await mkdir(join(distRoot, "renderer"), { recursive: true });
await cp(
  join(projectRoot, "src", "renderer", "index.html"),
  join(distRoot, "renderer", "index.html"),
);
execFileSync(process.execPath, [join(projectRoot, "scripts", "generate-control-plane-schema.mjs")], {
  cwd: projectRoot,
  env: { ...process.env, CODEX_WORKBENCH_DIST: distRoot },
  stdio: "inherit",
});
const worktreeStatus = git(["status", "--porcelain=v1", "--untracked-files=all"]) ?? "GIT_STATUS_UNAVAILABLE";
const runnerPath = join(projectRoot, "scripts", "stage-k1-d-real-planner-smoke.ts");
const buildProvenance = {
  schema_version: 1,
  source_commit: git(["rev-parse", "HEAD"]),
  worktree_state: worktreeStatus === "" ? "clean" : "dirty",
  worktree_state_sha256: sha256(worktreeStatus),
  source_tree_sha256: await sourceTreeSha256(),
  build_timestamp: new Date().toISOString(),
  runner_script_sha256: sha256(await readFile(runnerPath)),
  runner_script_path: "scripts/stage-k1-d-real-planner-smoke.ts",
  build_tool: "scripts/build.mjs",
};
await writeFile(join(distRoot, "k1d-build-provenance.json"), `${JSON.stringify(buildProvenance, null, 2)}\n`, "utf8");
process.stdout.write("BUILD PASS\n");
