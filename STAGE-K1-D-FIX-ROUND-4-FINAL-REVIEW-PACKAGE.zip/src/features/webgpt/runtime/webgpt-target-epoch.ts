import type { WebGptPageProbe } from "../types.ts";

/**
 * One immutable identity boundary for an automation operation.  The values
 * are deliberately captured together: a URL, DOM probe, observer, and
 * control lease from different navigation generations are not a valid
 * target proof.
 */
export interface WebGptTargetReadinessEpoch {
  readonly epochId: number;
  readonly navigationEpoch: number;
  readonly pageStateRevision: number;
  readonly controlEpoch: number;
  readonly operationId: string;
  readonly observerEpoch: number;
  readonly expectedChatUrl: string;
}

export interface WebGptTargetDispatchSnapshot {
  readonly epoch: WebGptTargetReadinessEpoch;
  readonly liveUrl: string;
  readonly pageProbeUrl: string;
  readonly actualChatUrl: string;
  readonly probe: WebGptPageProbe;
  readonly loading: boolean;
  readonly stateReady: boolean;
  readonly observerEpoch: number;
}

export interface WebGptTargetEpochState {
  readonly navigationEpoch: number;
  readonly pageStateRevision: number;
  readonly controlEpoch: number;
  readonly observerEpoch: number;
}

export interface WebGptPageProbeBoundary {
  readonly navigationEpoch: number;
  readonly pageStateRevision: number;
  readonly targetEpochId: number | null;
}

/**
 * A target epoch is current only when every part of the atomic boundary is
 * unchanged.  Keeping this predicate pure makes the stale-navigation and
 * control-takeover regressions testable without constructing Electron.
 */
export function isWebGptTargetEpochCurrent(
  epoch: WebGptTargetReadinessEpoch,
  current: WebGptTargetEpochState,
): boolean {
  return epoch.navigationEpoch === current.navigationEpoch
    && epoch.pageStateRevision === current.pageStateRevision
    && epoch.controlEpoch === current.controlEpoch
    && epoch.observerEpoch === current.observerEpoch;
}

export function targetEpochMismatchFields(
  epoch: WebGptTargetReadinessEpoch,
  current: WebGptTargetEpochState,
): string[] {
  const mismatches: string[] = [];
  if (epoch.navigationEpoch !== current.navigationEpoch) mismatches.push("navigationEpoch");
  if (epoch.pageStateRevision !== current.pageStateRevision) mismatches.push("pageStateRevision");
  if (epoch.controlEpoch !== current.controlEpoch) mismatches.push("controlEpoch");
  if (epoch.observerEpoch !== current.observerEpoch) mismatches.push("observerEpoch");
  return mismatches;
}

export function isWebGptPageProbeBoundaryCurrent(
  captured: WebGptPageProbeBoundary,
  current: WebGptPageProbeBoundary,
): boolean {
  return captured.navigationEpoch === current.navigationEpoch
    && captured.pageStateRevision === current.pageStateRevision
    && captured.targetEpochId === current.targetEpochId;
}
