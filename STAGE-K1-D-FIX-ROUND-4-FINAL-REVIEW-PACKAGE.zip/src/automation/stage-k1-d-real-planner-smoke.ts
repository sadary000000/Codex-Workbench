import { createHash } from "node:crypto";
import { mkdir, writeFile } from "node:fs/promises";
import { dirname } from "node:path";
import type {
  AutomationProviderPort,
  ProviderCapabilityFact,
  ProviderTargetResolution,
} from "./adapters.ts";
import { canonicalize, sha256Hex } from "./canonical.ts";
import { policyVersionPayload } from "./effective-policy.ts";
import { InputRefRegistry, type InputRefRegistration } from "./input-ref.ts";
import {
  buildPlannerProviderRequest,
  createPlannerProviderIntegrationService,
  plannerRequestIdempotencyRef,
  type PlannerIntegrationResult,
  type PlannerResultQuery,
  type PlannerStatusResult,
} from "./planner-provider-integration.ts";
import { AutomationStore } from "./store.ts";
import type { ActionAttempt, ActionIntent, ActionReceipt } from "./types.ts";
import type { PlanValidationResult, PlanValidationStatus } from "./planner-validator.ts";
import { normalizeRoleChatUrl, roleChatUrlsEquivalent } from "../shared/chat-url-identity.ts";
import { FINAL_PLANNER_RESULT_BEGIN, FINAL_PLANNER_RESULT_END, isKnownPlannerProviderErrorResponse } from "./planner-output-envelope.ts";
import { type StageK1DProvenance } from "./stage-k1-d-provenance.ts";
export type { StageK1DProvenance } from "./stage-k1-d-provenance.ts";
const STAGE = "STAGE-K1-D";
const PLANNER_ROLE = "PLANNER" as const;
const POLICY_VERSION_ID = "stage-k1-d-policy-v1";
const REQUIREMENT_VERSION_ID = "stage-k1-d-requirement-v1";
const PLAN_VERSION_ID = "stage-k1-d-plan-v1";
const STAGE_SPEC_ID = "stage-k1-d-current";
const STEP_SPEC_ID = "step-k1-d-current";
const DEFAULT_IDEMPOTENCY_LABEL = "stage-k1-d-real-planner-smoke-v1";
const HISTORICAL_REQUEST_ID = "wgpt-3f72b4b7-cd05-4594-b14b-34f537e58960";
const HISTORICAL_IDEMPOTENCY_REF = "k1-c:planner:9a8369761168a81b3602da1d40f4f2b6b5ca2ee0b7d577732b1c31b6a853406e";
const HISTORICAL_RESULT_SHA256 = "c8b345ed237f28ee7bc69c35adfea28c1946cb5dddca26733729b42421955bb4";
const HISTORICAL_ACTION_INTENT_ID = "f4a70e74-6ae8-4a2b-9e3a-1d59d84f62a3";
const HISTORICAL_ACTION_ATTEMPT_ID = "c87a55e9-11df-4eed-8251-2db1f8dbfc81";
const HISTORICAL_PROMPT_SHA256 = "d3ab7c3028a853a586387bdbc6a44cd336842b232b0104de697638cd39b25292";
const HISTORICAL_PROMPT_CHARS = 1471;
const HISTORICAL_RESULT_BYTES = 144;
const HISTORICAL_PROVIDER_SEMANTIC_SHA256 = "aa7a1e7d9f1f7c957f48fbad64f197ad6373769259370c8fb1a0d151b561675d";
const HISTORICAL_INPUT_REF = `automation-input-v1:${HISTORICAL_PROMPT_SHA256}`;

export interface StageK1DRealPlannerSmokeOptions {
  readonly store: AutomationStore;
  readonly provider: AutomationProviderPort;
  readonly requestManager: {
    readonly findByIdempotencyKey: (idempotencyKey: string) => Promise<SmokeRequestRecord | null>;
    readonly getRequestById?: (requestId: string) => Promise<SmokeRequestRecord>;
    readonly waitForRequest: (requestId: string, timeoutMs: number) => Promise<unknown>;
  };
  readonly inputRefs: InputRefRegistry;
  /** Provider-owned opaque target; the stage never interprets it. */
  readonly providerTargetRef: string;
  readonly providerProjectId: string;
  readonly automationProjectId: string;
  readonly outputPath: string;
  readonly timeoutMs: number;
  readonly idempotencyLabel?: string;
  readonly now?: () => string;
  readonly returnAutomationControl: () => Promise<unknown>;
  readonly openWorkspace: () => Promise<unknown>;
  readonly openPlannerTarget: () => Promise<unknown>;
  readonly recordTargetBinding?: (expectedChatUrl: string | null, details?: Readonly<Record<string, string | number | boolean | null>>) => void;
  /** Sanitized WebGPT target lifecycle trace; must contain no raw page data. */
  readonly getTargetIdentityTrace?: () => readonly Readonly<Record<string, unknown>>[];
  /** Positive redesign smoke is dormant unless a later explicit gate enables it. */
  readonly authorizePositiveRetry?: boolean;
  /** Build/package identity supplied by the packaged Workbench runtime. */
  readonly provenance?: StageK1DProvenance;
  readonly historicalRequestId?: string;
  readonly historicalIdempotencyRef?: string;
  readonly historicalResultSha256?: string;
  readonly historicalActionIntentId?: string;
  readonly historicalActionAttemptId?: string;
}

export interface StageK1DEvidence {
  readonly stage: typeof STAGE;
  readonly result: "PASS_REAL" | "FIX_REQUIRED" | "BLOCKED";
  readonly startedAt: string;
  readonly completedAt: string;
  readonly providerProjectId: string;
  readonly automationProjectId: string;
  readonly plannerTarget: {
    readonly providerTargetRef: string;
    readonly workflowRole: typeof PLANNER_ROLE;
    readonly resolution: Readonly<Record<string, unknown>>;
    readonly capabilities: readonly Readonly<Record<string, unknown>>[];
    readonly boundChatUrlSha256: string | null;
  };
  readonly requirement: {
    readonly requirementVersionId: string | null;
    readonly payloadSha256: string | null;
    readonly status: string | null;
    readonly canonicalPayloadLogged: false;
  };
  readonly plannerRequest: {
    readonly operation: string | null;
    readonly idempotencyRef: string | null;
    readonly inputRef: string | null;
    readonly inputSha256: string | null;
    readonly promptChars: number | null;
    readonly logicalPlannerRequestId?: string | null;
    readonly maxProviderAttempts?: number | null;
    readonly providerAttempts?: number;
    readonly attempt1?: Readonly<Record<string, unknown>> | null;
    readonly attempt2?: Readonly<Record<string, unknown>> | null;
    readonly requestBefore: Readonly<Record<string, unknown>> | null;
    readonly requestAfter: Readonly<Record<string, unknown>> | null;
    readonly realPlannerPrompts: number;
    readonly newRealPlannerPromptsThisRedesign?: number;
    readonly planPromotions?: number;
    readonly duplicatePlanPromotion?: 0;
    readonly retryBudgetExhausted?: boolean;
    readonly existingProviderRequestReused: boolean;
    readonly duplicatePlannerPrompt: 0;
    readonly blindResend: false;
  };
  readonly actionCorrelation: Readonly<Record<string, unknown>>;
  readonly providerResult: Readonly<Record<string, unknown>>;
  readonly targetLifecycle: readonly Readonly<Record<string, unknown>>[];
  readonly persistence: Readonly<Record<string, unknown>>;
  readonly provenance: StageK1DProvenance;
  readonly safety: {
    readonly executedSteps: false;
    readonly newNativeThreads: 0;
    readonly verifierStarted: false;
    readonly schedulerStarted: false;
    readonly rawPromptLogged: false;
    readonly rawResponseLogged: false;
  };
  readonly error: Readonly<Record<string, unknown>> | null;
}

interface StageFixture {
  readonly projectId: string;
  readonly requirementVersionId: string;
  readonly payloadSha256: string;
}

interface SmokePageState {
  readonly url?: string;
  readonly onChatPage?: boolean;
  readonly composerFound?: boolean;
  readonly generating?: boolean;
  readonly loginRequired?: boolean;
  readonly userCount?: number;
  readonly assistantCount?: number;
}

interface SmokeRequestRecord {
  readonly requestId: string;
  readonly state: string;
  readonly createdAt: string;
  readonly projectId: string | null;
  readonly role: string | null;
  readonly policyVersionId?: string | null;
  readonly idempotencyKey: string | null;
  readonly promptChars: number;
  readonly promptSha256: string;
  readonly submittedAt: string | null;
  readonly sendStartedAt: string | null;
  readonly completedAt: string | null;
  readonly semanticSha256?: string | null;
  readonly resultSha256?: string | null;
  readonly resultBytes?: number | null;
  readonly lastKnownPageState: SmokePageState | null;
  readonly error?: { readonly code?: string; readonly message?: string } | null;
}

interface RequestSummary {
  readonly requestId: string;
  readonly state: string;
  readonly projectId: string | null;
  readonly role: string | null;
  readonly policyVersionId: string | null;
  readonly idempotencyKey: string | null;
  readonly promptChars: number;
  readonly promptSha256: string;
  readonly resultSha256: string | null;
  readonly resultBytes: number | null;
    readonly targetIdentitySha256: string | null;
    readonly currentPageIdentitySha256: string | null;
  readonly lastKnownPageUrlSha256: string | null;
  readonly sendStartedAt: string | null;
  readonly submittedAt: string | null;
  readonly completedAt: string | null;
  readonly lastKnownPageState: Readonly<Record<string, unknown>> | null;
  readonly errorCode: string | null;
}

function hash(value: string | null | undefined): string | null {
  return value ? createHash("sha256").update(value, "utf8").digest("hex") : null;
}

function evidenceProvenance(value: StageK1DProvenance | undefined, evidenceTimestamp: string): StageK1DProvenance {
  const empty: StageK1DProvenance = {
    source_commit: null,
    worktree_state: null,
    worktree_state_sha256: null,
    source_tree_sha256: null,
    build_timestamp: null,
    package_timestamp: null,
    executable_path: null,
    executable_sha256: null,
    expected_executable_sha256: null,
    runner_script_sha256: null,
    expected_runner_script_sha256: null,
    evidence_timestamp: evidenceTimestamp,
    verified: false,
    verification_errors: ["PACKAGED_PROVENANCE_NOT_SUPPLIED"],
  };
  if (!value) return empty;
  return {
    ...value,
    evidence_timestamp: evidenceTimestamp,
    verified: value.verified === true && value.verification_errors.length === 0,
    verification_errors: [...value.verification_errors],
  };
}

function boundedError(error: unknown, redactions: readonly string[] = []): Readonly<Record<string, unknown>> {
  const rawCode = error && typeof error === "object" ? (error as { code?: unknown }).code : null;
  const code = typeof rawCode === "string" && rawCode.trim() ? rawCode.trim().slice(0, 128) : "K1D_STAGE_ERROR";
  let message = error instanceof Error ? error.message : String(error);
  for (const value of redactions) if (value) message = message.split(value).join("[REDACTED]");
  return { code, message: message.slice(0, 512) };
}

function safePageState(record: SmokeRequestRecord): Readonly<Record<string, unknown>> | null {
  const page = record.lastKnownPageState;
  if (!page) return null;
  return {
    urlSha256: hash(page.url),
    onChatPage: page.onChatPage,
    composerFound: page.composerFound,
    generating: page.generating,
    loginRequired: page.loginRequired,
    userCount: page.userCount,
    assistantCount: page.assistantCount,
  };
}

function summarizeRequest(record: SmokeRequestRecord | null): RequestSummary | null {
  if (!record) return null;
  return {
    requestId: record.requestId,
    state: record.state,
    projectId: record.projectId ?? null,
    role: record.role ?? null,
    policyVersionId: record.policyVersionId ?? null,
    idempotencyKey: record.idempotencyKey ?? null,
    promptChars: record.promptChars,
    promptSha256: record.promptSha256,
    resultSha256: record.resultSha256 ?? null,
    resultBytes: record.resultBytes ?? null,
    targetIdentitySha256: hash(stringField(record, "targetChatUrl")),
    currentPageIdentitySha256: hash(stringField(record, "chatUrl")),
    lastKnownPageUrlSha256: hash(record.lastKnownPageState?.url),
    sendStartedAt: record.sendStartedAt,
    submittedAt: record.submittedAt,
    completedAt: record.completedAt,
    lastKnownPageState: safePageState(record),
    errorCode: record.error?.code ?? null,
  };
}

function plannerLogicalIdentity(request: ReturnType<typeof buildPlannerProviderRequest>): string {
  const { inputRefs: _inputRefs, ...logical } = request;
  return canonicalize(logical, "planner.logical-request");
}

function resultStatus(result: PlannerIntegrationResult | null, request: SmokeRequestRecord | null): StageK1DEvidence["result"] {
  if (result?.status === "PLAN_READY") return "PASS_REAL";
  const code = result?.errorCode ?? "";
  const requestCode = request?.error?.code ?? "";
  if (code.startsWith("WEBGPT_LOGIN") || code.includes("UNAVAILABLE") || code.includes("AUTH") || code.includes("TARGET_UNAVAILABLE")
    || requestCode === "WAITING_IDENTITY_READY" || requestCode === "WEBGPT_TARGET_CHAT_MISMATCH" || requestCode === "ROLE_CHAT_MISMATCH" || requestCode === "WEBGPT_LOGIN_REQUIRED") return "BLOCKED";
  return result ? "FIX_REQUIRED" : "BLOCKED";
}

function validationSummary(validation: PlanValidationResult | null): Readonly<Record<string, unknown>> {
  if (!validation) return { status: null, valid: false, errorCodes: [] };
  return {
    status: validation.status as PlanValidationStatus,
    valid: validation.valid,
    errorCodes: validation.errors.map((item) => item.code),
    warningCodes: validation.warnings.map((item) => item.code),
    blockingQuestionCount: validation.blockingQuestions.length,
    missingRequirementFieldCount: validation.missingRequirementFields.length,
  };
}

async function ensureStageFixture(store: AutomationStore, projectId: string, timestamp: string): Promise<StageFixture> {
  const existing = await store.get("automationProjects", projectId);
  if (existing) throw new Error("K1D_FIXTURE_PROJECT_ALREADY_EXISTS");
  const project = await store.createAutomationProject({ projectId, name: "STAGE-K1-D bounded Planner smoke", lifecycle: "REQUIREMENTS_CONFIRMED" });
  await store.createPolicyVersion({
    policyVersionId: POLICY_VERSION_ID,
    projectId: project.projectId,
    version: 1,
    preset: "stage-k1-d-real-smoke",
    payload: policyVersionPayload({
      // K1-D redesign owns one logical request with up to two independent
      // provider attempts; the ActionAttempt guard remains the authoritative
      // retry budget, while the provider policy must admit both prompts.
      maxPromptDispatches: 2,
      maxRepairDispatches: 0,
      maxRetryDispatches: 0,
      maxNewChatDispatches: 0,
      allowedOperations: ["PROMPT", "VERIFY"],
      requireHumanGateFor: [],
      allowDataEgress: false,
      allowSideEffects: false,
    }),
    supersedes: null,
  });
  const canonicalPayload = canonicalize({
    schemaVersion: 1,
    goal: "Produce one bounded planning-only candidate for STAGE-K1-D.",
    scope: "PLANNING_ONLY",
    constraints: [
      "Do not execute any step.",
      "Do not create Native Threads.",
      "Return one detailed current stage with one verifiable step.",
    ],
  });
  const requirement = await store.createRequirementVersion({
    projectId: project.projectId,
    requirementVersionId: REQUIREMENT_VERSION_ID,
    version: 1,
    status: "CONFIRMED",
    confirmedAt: timestamp,
    origin: { originType: "INITIAL", source: "SYSTEM", sourceRef: "stage-k1-d-test-fixture" },
    canonicalPayload,
  });
  return { projectId: project.projectId, requirementVersionId: requirement.requirementVersionId, payloadSha256: requirement.payloadSha256 };
}

export function buildPlannerPrompt(requirementPayload: string, projectId: string, requirementVersionId: string, requirementPayloadSha256: string): string {
  return [
    "You are the planning-only provider for STAGE-K1-D.",
    `Return exactly one machine envelope: ${FINAL_PLANNER_RESULT_BEGIN}`,
    '{"schemaVersion":1,<the K1-B PlanCandidate fields>}',
    `${FINAL_PLANNER_RESULT_END}. Emit exactly one BEGIN and one END marker, no Markdown fence, no prose inside the envelope, and no semantic text after END. Keep the response bounded.`,
    "The object must satisfy the K1-B PlanCandidate contract and must use these exact identities:",
    `planVersionId=${PLAN_VERSION_ID}`,
    `projectId=${projectId}`,
    `requirementVersionId=${requirementVersionId}`,
    `requirementPayloadSha256=${requirementPayloadSha256}`,
    "Use version=1, supersedes=null, currentStageId=stage-k1-d-current.",
    "Use exactly one DETAILED stage with stageSpecId=stage-k1-d-current, stageKey=K1-D-PLANNING, ordinal=0, specVersion=1, supersedes=null, dependsOn=[], non-empty objective, acceptanceCriteria, assumptions=[], risks=[].",
    "Use exactly one PLANNER_STEP under that stage with stepSpecId=step-k1-d-current, stepKey=K1-D-VALIDATE, ordinal=0, specVersion=1, supersedes=null, non-empty objective, inputs, expectedOutputs, acceptanceCriteria, assumptions=[], constraints=[], riskClass=LOW, sideEffectClass=RECONCILABLE.",
    "Set ambiguity to {\"blockingQuestions\":[],\"missingRequirementFields\":[],\"assumptions\":[]}.",
    "The requirement below is a non-sensitive test fixture. Do not execute it; only return the candidate JSON.",
    requirementPayload,
  ].join("\n");
}

function stringField(value: unknown, key: string): string | null {
  if (!value || typeof value !== "object" || Array.isArray(value)) return null;
  const raw = (value as Record<string, unknown>)[key];
  return typeof raw === "string" && raw.trim() ? raw.trim() : null;
}

function chatIdentityMatches(record: SmokeRequestRecord | null): boolean {
  if (!record?.lastKnownPageState?.url) return false;
  const target = stringField(record, ["target", "Chat", "Url"].join(""));
  if (!target) return false;
  try {
    return roleChatUrlsEquivalent(normalizeRoleChatUrl(target), normalizeRoleChatUrl(record.lastKnownPageState.url));
  } catch {
    return false;
  }
}

function extractChatUrl(value: unknown): string | null {
  if (!value || typeof value !== "object" || Array.isArray(value)) return null;
  const record = value as Record<string, unknown>;
  const raw = record.chatUrl ?? record.ChatUrl;
  return typeof raw === "string" && raw.trim() ? raw.trim() : null;
}

async function writeEvidence(path: string, evidence: StageK1DEvidence): Promise<void> {
  await mkdir(dirname(path), { recursive: true });
  await writeFile(path, `${JSON.stringify(evidence, null, 2)}\n`, "utf8");
}

/**
 * Runs exactly one bounded real Planner request through the provider-neutral
 * production composition.  The fixture is deliberately isolated in the
 * caller-supplied Automation DB; only the WebGPT Role session is real.
 */
export async function runStageK1DRealPlannerSmoke(options: StageK1DRealPlannerSmokeOptions): Promise<StageK1DEvidence> {
  const now = options.now ?? (() => new Date().toISOString());
  const startedAt = now();
  const providerProjectId = options.providerProjectId.trim();
  const automationProjectId = options.automationProjectId.trim();
  const providerTargetRef = options.providerTargetRef.trim();
  const idempotencyLabel = options.idempotencyLabel?.trim() || DEFAULT_IDEMPOTENCY_LABEL;
  let requirementVersionId: string | null = null;
  let requirementPayloadSha256: string | null = null;
  let targetResolution: ProviderTargetResolution | null = null;
  let capabilities: readonly ProviderCapabilityFact[] = [];
  let boundChatUrlSha256: string | null = null;
  let inputRegistration: InputRefRegistration | null = null;
  let idempotencyRef: string | null = null;
  let plannerRequest: ReturnType<typeof buildPlannerProviderRequest> | null = null;
  let requestBefore: SmokeRequestRecord | null = null;
  let requestAfter: SmokeRequestRecord | null = null;
  let result: PlannerIntegrationResult | null = null;
  let statusQuery: PlannerStatusResult | null = null;
  let resultQuery: PlannerResultQuery | null = null;
  let actionCorrelation: Readonly<Record<string, unknown>> = {};
  let targetLifecycle: readonly Readonly<Record<string, unknown>>[] = [];
  let bindingLifecycle: readonly Readonly<Record<string, unknown>>[] = [];
  let persistence: Readonly<Record<string, unknown>> = { attempted: false, reopened: false };
  let error: Readonly<Record<string, unknown>> | null = null;
  let promptForRedaction = "";
  let storeClosed = false;

  try {
    if (!providerProjectId || !automationProjectId || !providerTargetRef || providerProjectId !== automationProjectId) throw new Error("K1D_PROJECT_SCOPE_MISMATCH");
    const created = await ensureStageFixture(options.store, automationProjectId, startedAt);
    requirementVersionId = created.requirementVersionId;
    requirementPayloadSha256 = created.payloadSha256;
    // `openWorkspace` is the automation-safe open operation, but the current
    // Workbench implementation deliberately leaves the workspace in
    // USER_CONTROL after opening it.  Return control only after that
    // transition; doing it in the opposite order makes the subsequent target
    // open fail with WEBGPT_USER_CONTROL without sending a prompt.
    await options.openWorkspace();
    await options.returnAutomationControl();
    const opened = await options.openPlannerTarget();
    boundChatUrlSha256 = hash(extractChatUrl(opened));
    targetResolution = await options.provider.resolveTarget({ workflowRole: PLANNER_ROLE, providerTargetRef });
    capabilities = await options.provider.capabilities();
    bindingLifecycle = [{
      stage: "TARGET_BINDING_RESOLVED",
      at: now(),
      providerTargetRefSha256: hash(providerTargetRef),
      boundChatUrlSha256,
      resolutionStatus: targetResolution.status,
      capability: targetResolution.capability ?? null,
    }];
    options.recordTargetBinding?.(extractChatUrl(opened), {
      phase: "planner_binding_resolved",
      resolutionStatus: targetResolution.status,
      capability: targetResolution.capability ?? null,
    });
    if (targetResolution.status !== "AVAILABLE" || !capabilities.some((item) => item.code === "AVAILABLE")) {
      throw new Error(`K1D_TARGET_NOT_READY:${targetResolution.capability ?? "UNKNOWN"}`);
    }

    const requirement = await options.store.get("requirementVersions", requirementVersionId);
    if (!requirement) throw new Error("K1D_REQUIREMENT_FIXTURE_MISSING");
    promptForRedaction = buildPlannerPrompt(requirement.canonicalPayload, automationProjectId, requirement.requirementVersionId, requirement.payloadSha256);
    inputRegistration = options.inputRefs.register({ kind: "OTHER", payload: promptForRedaction, ownerRef: idempotencyLabel });
    plannerRequest = buildPlannerProviderRequest({
      projectId: automationProjectId,
      requirement,
      providerTargetRef,
      operation: "PLAN_REQUIREMENT",
      planningConstraints: ["planning-only", "no-step-execution", "return-k1-b-candidate"],
      inputRefs: [inputRegistration.inputRef],
    });
    idempotencyRef = plannerRequestIdempotencyRef(plannerRequest, idempotencyLabel);
    requestBefore = await options.requestManager.findByIdempotencyKey(idempotencyRef);
    result = await createPlannerProviderIntegrationService({ store: options.store, provider: options.provider }).createPlanFromRequirement({
      projectId: automationProjectId,
      requirementVersionId,
      providerTargetRef,
      operation: "PLAN_REQUIREMENT",
      planningConstraints: plannerRequest.planningConstraints,
      inputRefs: [inputRegistration.inputRef],
      idempotencyRef: idempotencyLabel,
      requestId: "stage-k1-d-planner-request-v1",
    });

    // If the Request Manager never entered SUBMITTING and never recorded a
    // send start, there is no external side effect to wait on.  Reconcile the
    // same ActionAttempt once for evidence, then close the smoke immediately;
    // repeatedly reopening an unavailable target cannot make a prompt safe.
    requestAfter = await options.requestManager.findByIdempotencyKey(idempotencyRef);
    const noPromptSideEffect = requestAfter !== null
      && requestAfter.submittedAt === null
      && requestAfter.sendStartedAt === null;
    if (result.status === "RECOVERY_REQUIRED" && result.actionAttemptId && noPromptSideEffect) {
      result = await createPlannerProviderIntegrationService({ store: options.store, provider: options.provider }).reconcilePlannerRequest({ projectId: automationProjectId, actionAttemptId: result.actionAttemptId });
    } else {
      const deadline = Date.now() + Math.max(5_000, Math.min(options.timeoutMs, 300_000));
      while (result.status === "RECOVERY_REQUIRED" && result.actionAttemptId && Date.now() < deadline) {
        if (result.providerRequestRef) {
          const remaining = Math.max(1_000, Math.min(deadline - Date.now(), 30_000));
          await options.requestManager.waitForRequest(result.providerRequestRef, remaining);
        }
        result = await createPlannerProviderIntegrationService({ store: options.store, provider: options.provider }).reconcilePlannerRequest({ projectId: automationProjectId, actionAttemptId: result.actionAttemptId });
        if (result.status !== "RECOVERY_REQUIRED") break;
      }
    }
    requestAfter = await options.requestManager.findByIdempotencyKey(idempotencyRef);

    const snapshot = await options.store.snapshot();
    const intent = result.actionIntentId ? snapshot.actionIntents.find((item) => item.intentId === result!.actionIntentId) ?? null : null;
    const attempt = result.actionAttemptId ? snapshot.actionAttempts.find((item) => item.actionAttemptId === result!.actionAttemptId) ?? null : null;
    const receipt = attempt ? snapshot.actionReceipts.find((item) => item.actionAttemptId === attempt.actionAttemptId) ?? null : null;
    actionCorrelation = {
      actionIntentId: intent?.intentId ?? result.actionIntentId,
      actionAttemptId: attempt?.actionAttemptId ?? result.actionAttemptId,
      policyVersionId: intent?.policyVersionId ?? null,
      idempotencyRef: intent?.idempotencyRef ?? idempotencyRef,
      providerTargetRef,
      providerRequestRef: result.providerRequestRef,
      providerRequestExternalRef: result.providerRequestExternalRef,
      providerObservationExternalRef: result.providerObservationExternalRef,
      receiptId: receipt?.receiptId ?? result.receiptId,
      receiptStatus: receipt?.status ?? null,
      receiptOutcomeCertainty: receipt?.outcomeCertainty ?? null,
      receiptExternalStatus: receipt?.externalStatus ?? null,
      receiptReconcileState: receipt?.reconcileState ?? null,
      requestErrorCode: requestAfter?.error?.code ?? null,
      requirementVersionId,
      requirementPayloadSha256,
      targetIdentityMatch: chatIdentityMatches(requestAfter),
      providerRequestIdentityMatch: Boolean(result.providerRequestRef && requestAfter?.requestId === result.providerRequestRef),
      providerObservationIdentityMatch: Boolean(result.providerObservationExternalRef && receipt?.providerObservationRef === result.providerObservationExternalRef),
    };
    if (result.actionIntentId) {
      statusQuery = await createPlannerProviderIntegrationService({ store: options.store, provider: options.provider }).plannerStatus({ projectId: automationProjectId, actionIntentId: result.actionIntentId });
      resultQuery = await createPlannerProviderIntegrationService({ store: options.store, provider: options.provider }).plannerResult({ projectId: automationProjectId, actionIntentId: result.actionIntentId });
    }

    if (result.status === "PLAN_READY" && result.planVersion) {
      persistence = { attempted: true, reopened: false, beforeActivePlanVersionId: (await options.store.get("automationProjects", automationProjectId))?.activePlanVersionId ?? null };
      const databasePath = options.store.filePath;
      await options.store.close();
      storeClosed = true;
      const reopened = new AutomationStore(databasePath);
      const reopenedProject = await reopened.get("automationProjects", automationProjectId);
      const reopenedPlan = await reopened.getCurrentPlanVersion(automationProjectId);
      persistence = {
        attempted: true,
        reopened: true,
        activePlanVersionId: reopenedProject?.activePlanVersionId ?? null,
        planVersionId: reopenedPlan?.planVersionId ?? null,
        planStatus: reopenedPlan?.status ?? null,
        requirementVersionId: reopenedPlan?.requirementVersionId ?? null,
        activePointerMatches: reopenedProject?.activePlanVersionId === result.planVersion.planVersionId,
        planSurvivedRestart: reopenedPlan?.planVersionId === result.planVersion.planVersionId,
      };
      await reopened.close();
    }
  } catch (caught) {
    error = boundedError(caught, [promptForRedaction]);
  } finally {
    targetLifecycle = [
      ...bindingLifecycle,
      ...(options.getTargetIdentityTrace?.().map((item) => ({ ...item })) ?? []),
    ];
    if (inputRegistration) options.inputRefs.release(inputRegistration.inputRef, idempotencyLabel);
    if (!storeClosed) await options.store.close().catch(() => undefined);
  }

  const observedResult = resultStatus(result, requestAfter);
  const promptActuallySubmitted = requestAfter?.submittedAt !== null && requestAfter?.submittedAt !== undefined;
  const exactSinglePrompt = requestBefore === null && promptActuallySubmitted;
  const correlationClosed = actionCorrelation.targetIdentityMatch === true
    && actionCorrelation.providerRequestIdentityMatch === true
    && actionCorrelation.providerObservationIdentityMatch === true;
  const persistenceClosed = persistence.activePointerMatches === true && persistence.planSurvivedRestart === true;
  const queryClosed = result?.status === "PLAN_READY"
    && statusQuery?.planVersionId === result.planVersion?.planVersionId
    && resultQuery?.planVersion?.planVersionId === result.planVersion?.planVersionId;
  const completedAt = now();
  const provenance = evidenceProvenance(options.provenance, completedAt);
  const finalResult: StageK1DEvidence["result"] = observedResult === "PASS_REAL"
    && exactSinglePrompt
    && correlationClosed
    && persistenceClosed
    && queryClosed
    && provenance.verified
    ? "PASS_REAL"
    : observedResult === "BLOCKED" ? "BLOCKED" : "FIX_REQUIRED";

  const evidence: StageK1DEvidence = {
    stage: STAGE,
    result: finalResult,
    startedAt,
    completedAt,
    providerProjectId,
    automationProjectId,
    plannerTarget: {
      providerTargetRef,
      workflowRole: PLANNER_ROLE,
      resolution: targetResolution ? { provider: targetResolution.provider, status: targetResolution.status, capability: targetResolution.capability } : {},
      capabilities: capabilities.map((item) => ({ provider: item.provider, code: item.code, detail: item.detail ?? null })),
      boundChatUrlSha256,
    },
    requirement: {
      requirementVersionId,
      payloadSha256: requirementPayloadSha256,
      status: requirementVersionId ? "CONFIRMED" : null,
      canonicalPayloadLogged: false,
    },
    plannerRequest: {
      operation: plannerRequest?.operation ?? null,
      idempotencyRef,
      inputRef: inputRegistration?.inputRef ?? null,
      inputSha256: inputRegistration?.sha256 ?? null,
      promptChars: inputRegistration?.length ?? null,
      requestBefore: requestBefore ? { ...summarizeRequest(requestBefore)! } : null,
      requestAfter: requestAfter ? { ...summarizeRequest(requestAfter)! } : null,
      realPlannerPrompts: requestBefore || !promptActuallySubmitted ? 0 : 1,
      existingProviderRequestReused: requestBefore !== null,
      duplicatePlannerPrompt: 0,
      blindResend: false,
    },
    actionCorrelation,
    providerResult: {
      status: result?.status ?? null,
      errorCode: result?.errorCode ?? null,
      errorMessage: result?.errorMessage ? result.errorMessage.slice(0, 512) : null,
      providerRequestRef: result?.providerRequestRef ?? null,
      receiptId: result?.receiptId ?? null,
      planVersionId: result?.planVersion?.planVersionId ?? null,
      planVersion: result?.planVersion?.version ?? null,
      validation: validationSummary(result?.validation ?? null),
      statusQuery: statusQuery ? { ...statusQuery } : null,
      resultQuery: resultQuery ? { actionIntentId: resultQuery.actionIntentId, actionAttemptId: resultQuery.actionAttemptId, receiptStatus: resultQuery.receipt?.status ?? null, planVersionId: resultQuery.planVersion?.planVersionId ?? null } : null,
    },
    targetLifecycle,
    persistence,
    provenance,
    safety: {
      executedSteps: false,
      newNativeThreads: 0,
      verifierStarted: false,
      schedulerStarted: false,
      rawPromptLogged: false,
      rawResponseLogged: false,
    },
    error,
  };
  await writeEvidence(options.outputPath, evidence);
  return evidence;
}

function summarizePlannerAttempt(attempt: ActionAttempt | null, receipt: ActionReceipt | null): Readonly<Record<string, unknown>> | null {
  if (!attempt) return null;
  return {
    actionAttemptId: attempt.actionAttemptId,
    logicalPlannerRequestId: attempt.logicalPlannerRequestId ?? null,
    attemptNumber: attempt.attemptNumber ?? null,
    dispatchNumber: attempt.dispatchNumber,
    state: attempt.state,
    recoveryState: attempt.recoveryState,
    plannerResultClassification: attempt.plannerResultClassification ?? null,
    externalSideEffectCertainty: attempt.externalSideEffectCertainty ?? null,
    providerRequestRef: attempt.providerRequestRef ?? null,
    providerObservationRef: attempt.providerObservationRef ?? null,
    providerSemanticSha256: attempt.providerSemanticSha256 ?? null,
    receiptStatus: receipt?.status ?? null,
    receiptOutcomeCertainty: receipt?.outcomeCertainty ?? null,
    receiptReconcileState: receipt?.reconcileState ?? null,
    receiptResultHash: receipt?.resultHash ?? null,
  };
}

function requireSmokeRequestReader(options: StageK1DRealPlannerSmokeOptions): (requestId: string) => Promise<SmokeRequestRecord> {
  if (!options.requestManager.getRequestById) throw new Error("K1D_REQUEST_STATUS_READER_REQUIRED");
  return options.requestManager.getRequestById;
}

/**
 * Positive K1-D redesign smoke.  It binds the known historical Attempt #1 to
 * the existing K0 Action ledger, then (only when the caller supplies the later
 * explicit authorization) dispatches exactly one new Attempt #2.  The normal
 * single-attempt smoke remains available for compatibility, but this function
 * is the only path that can produce the redesign PASS counters.
 */
export async function runStageK1DPositiveRetrySmoke(options: StageK1DRealPlannerSmokeOptions): Promise<StageK1DEvidence> {
  const now = options.now ?? (() => new Date().toISOString());
  const startedAt = now();
  const providerProjectId = options.providerProjectId.trim();
  const automationProjectId = options.automationProjectId.trim();
  const providerTargetRef = options.providerTargetRef.trim();
  const historicalRequestId = options.historicalRequestId?.trim() || HISTORICAL_REQUEST_ID;
  const historicalIdempotencyRef = options.historicalIdempotencyRef?.trim() || HISTORICAL_IDEMPOTENCY_REF;
  const historicalResultSha256 = options.historicalResultSha256?.trim() || HISTORICAL_RESULT_SHA256;
  const historicalActionIntentId = options.historicalActionIntentId?.trim() || HISTORICAL_ACTION_INTENT_ID;
  const historicalActionAttemptId = options.historicalActionAttemptId?.trim() || HISTORICAL_ACTION_ATTEMPT_ID;
  const logicalPlannerRequestId = historicalActionIntentId;
  const requestReader = requireSmokeRequestReader(options);
  let requirementVersionId: string | null = null;
  let requirementPayloadSha256: string | null = null;
  let targetResolution: ProviderTargetResolution | null = null;
  let capabilities: readonly ProviderCapabilityFact[] = [];
  let boundChatUrlSha256: string | null = null;
  let inputRegistration: InputRefRegistration | null = null;
  let plannerRequest: ReturnType<typeof buildPlannerProviderRequest> | null = null;
  let historicalRequest: SmokeRequestRecord | null = null;
  let historicalPlannerRequest: ReturnType<typeof buildPlannerProviderRequest> | null = null;
  let retryRequest: SmokeRequestRecord | null = null;
  let result: PlannerIntegrationResult | null = null;
  let statusQuery: PlannerStatusResult | null = null;
  let resultQuery: PlannerResultQuery | null = null;
  let actionCorrelation: Readonly<Record<string, unknown>> = {};
  let targetLifecycle: readonly Readonly<Record<string, unknown>>[] = [];
  let bindingLifecycle: readonly Readonly<Record<string, unknown>>[] = [];
  let persistence: Readonly<Record<string, unknown>> = { attempted: false, reopened: false };
  let error: Readonly<Record<string, unknown>> | null = null;
  let promptForRedaction = "";
  let storeClosed = false;
  let preconditionSnapshot: Readonly<Record<string, unknown>> = {};
  let finalSnapshot: Awaited<ReturnType<AutomationStore["snapshot"]>> | null = null;

  try {
    if (!providerProjectId || !automationProjectId || !providerTargetRef || providerProjectId !== automationProjectId) throw new Error("K1D_PROJECT_SCOPE_MISMATCH");
    const created = await ensureStageFixture(options.store, automationProjectId, startedAt);
    requirementVersionId = created.requirementVersionId;
    requirementPayloadSha256 = created.payloadSha256;
    await options.openWorkspace();
    await options.returnAutomationControl();
    const opened = await options.openPlannerTarget();
    boundChatUrlSha256 = hash(extractChatUrl(opened));
    targetResolution = await options.provider.resolveTarget({ workflowRole: PLANNER_ROLE, providerTargetRef });
    capabilities = await options.provider.capabilities();
    bindingLifecycle = [{
      stage: "TARGET_BINDING_RESOLVED",
      at: now(),
      providerTargetRefSha256: hash(providerTargetRef),
      boundChatUrlSha256,
      resolutionStatus: targetResolution.status,
      capability: targetResolution.capability ?? null,
    }];
    options.recordTargetBinding?.(extractChatUrl(opened), {
      phase: "planner_binding_resolved",
      resolutionStatus: targetResolution.status,
      capability: targetResolution.capability ?? null,
    });
    if (targetResolution.status !== "AVAILABLE" || !capabilities.some((item) => item.code === "AVAILABLE")) throw new Error(`K1D_TARGET_NOT_READY:${targetResolution.capability ?? "UNKNOWN"}`);

    const requirement = await options.store.get("requirementVersions", requirementVersionId);
    if (!requirement) throw new Error("K1D_REQUIREMENT_FIXTURE_MISSING");
    promptForRedaction = buildPlannerPrompt(requirement.canonicalPayload, automationProjectId, requirement.requirementVersionId, requirement.payloadSha256);
    inputRegistration = options.inputRefs.register({ kind: "OTHER", payload: promptForRedaction, ownerRef: historicalIdempotencyRef });
    plannerRequest = buildPlannerProviderRequest({
      projectId: automationProjectId,
      requirement,
      providerTargetRef,
      operation: "PLAN_REQUIREMENT",
      planningConstraints: ["planning-only", "no-step-execution", "return-k1-b-candidate"],
      inputRefs: [inputRegistration.inputRef],
    });
    historicalPlannerRequest = buildPlannerProviderRequest({
      projectId: automationProjectId,
      requirement,
      providerTargetRef,
      operation: "PLAN_REQUIREMENT",
      planningConstraints: plannerRequest.planningConstraints,
      priorPlanVersionId: plannerRequest.priorPlanVersionId,
      targetStageId: plannerRequest.targetStageId,
      inputRefs: [HISTORICAL_INPUT_REF],
    });
    const logicalPlannerIdentityMatches = plannerLogicalIdentity(plannerRequest) === plannerLogicalIdentity(historicalPlannerRequest);
    if (!logicalPlannerIdentityMatches) throw new Error("K1D_HISTORICAL_LOGICAL_REQUEST_IDENTITY_INVALID");

    historicalRequest = await options.requestManager.findByIdempotencyKey(historicalIdempotencyRef);
    if (!historicalRequest
      || historicalRequest.requestId !== historicalRequestId
      || historicalRequest.state !== "COMPLETED"
      || historicalRequest.projectId !== providerProjectId
      || historicalRequest.role !== PLANNER_ROLE
      || historicalRequest.policyVersionId !== POLICY_VERSION_ID
      || historicalRequest.idempotencyKey !== historicalIdempotencyRef
      || historicalRequest.promptChars !== HISTORICAL_PROMPT_CHARS
      || historicalRequest.promptSha256 !== HISTORICAL_PROMPT_SHA256
      || historicalRequest.semanticSha256 !== HISTORICAL_PROVIDER_SEMANTIC_SHA256
      || historicalRequest.resultSha256 !== historicalResultSha256
      || historicalRequest.resultBytes !== HISTORICAL_RESULT_BYTES
      || !historicalRequest.createdAt
      || !historicalRequest.completedAt
      || historicalRequest.submittedAt === null
      || historicalRequest.sendStartedAt === null) {
      throw new Error("K1D_HISTORICAL_ATTEMPT_CORRELATION_INVALID");
    }
    if (!historicalRequest.lastKnownPageState?.url || !chatIdentityMatches(historicalRequest)) throw new Error("K1D_HISTORICAL_TARGET_IDENTITY_INVALID");
    const historicalResult = options.provider.readResult
      ? await options.provider.readResult({ providerRequestRef: historicalRequest.requestId })
      : null;
    if (!historicalResult
      || historicalResult.provider !== options.provider.provider
      || historicalResult.providerRequestRef !== historicalRequest.requestId
      || historicalResult.state !== "COMPLETED"
      || historicalResult.response === null
      || !isKnownPlannerProviderErrorResponse(historicalResult.response)
      || (historicalResult.resultHash !== null && historicalResult.resultHash !== historicalResultSha256)) {
      throw new Error("K1D_HISTORICAL_RESULT_NOT_KNOWN_RETRYABLE_ERROR");
    }

    const intent: ActionIntent = await options.store.createActionIntent({
      intentId: historicalActionIntentId,
      projectId: automationProjectId,
      actionType: "PLANNER_REQUEST",
      targetRef: providerTargetRef,
      sideEffectClass: "RECONCILABLE",
      payloadRef: inputRegistration.inputRef,
      payloadHash: null,
      executionOptions: {
        plannerOperation: plannerRequest.operation,
        requirementVersionId: plannerRequest.requirementVersionId,
        requirementPayloadSha256: plannerRequest.requirementPayloadSha256,
        priorPlanVersionId: plannerRequest.priorPlanVersionId,
        targetStageId: plannerRequest.targetStageId,
        inputRefCount: plannerRequest.inputRefs.length,
        planningConstraintCount: plannerRequest.planningConstraints.length,
      },
      plannerRequestCanonical: canonicalize(plannerRequest, "planner.request"),
      plannerRequirementVersionId: plannerRequest.requirementVersionId,
      plannerRequirementPayloadSha256: plannerRequest.requirementPayloadSha256,
      plannerOperation: plannerRequest.operation,
      plannerMaxProviderAttempts: 2,
      logicalPlannerRequestId,
      idempotencyRef: historicalIdempotencyRef,
      expectedOutcomeRef: historicalIdempotencyRef,
      policyVersionId: POLICY_VERSION_ID,
    });
    await options.store.markActionIntentDispatchEligible(intent.intentId, { actorType: "AUTOMATION", correlationId: logicalPlannerRequestId });
    const bound = await options.store.bindHistoricalPlannerAttempt({
      projectId: automationProjectId,
      actionIntentId: intent.intentId,
      logicalPlannerRequestId,
      actionAttemptId: historicalActionAttemptId,
      provider: options.provider.provider,
      providerRequestRef: historicalRequest.requestId,
      historicalPlannerRequestCanonical: canonicalize(historicalPlannerRequest, "historicalAttempt.plannerRequestCanonical"),
      sourceIdempotencyRef: historicalIdempotencyRef,
      sourceInputRef: HISTORICAL_INPUT_REF,
      sourceInputSha256: HISTORICAL_PROMPT_SHA256,
      sourceInputLength: HISTORICAL_PROMPT_CHARS,
      providerSemanticSha256: historicalRequest.semanticSha256 ?? null,
      sourceCreatedAt: historicalRequest.createdAt,
      sourceStartedAt: historicalRequest.sendStartedAt,
      sourceCompletedAt: historicalRequest.completedAt,
      sourceResultSha256: historicalResultSha256,
    });
    preconditionSnapshot = {
      logicalPlannerRequestCount: 1,
      providerAttemptCount: 1,
      attempt1Terminal: bound.attempt.state === "FAILED",
      attempt1Classification: bound.attempt.plannerResultClassification,
      attempt1ReceiptStatus: bound.receipt.status,
      attempt1ExternalSideEffectCertainty: bound.attempt.externalSideEffectCertainty,
      noPromotedPlan: true,
      maxProviderAttempts: 2,
      targetResolution: targetResolution.status,
      targetIdentityStable: boundChatUrlSha256 !== null,
    };
    if (options.authorizePositiveRetry !== true) throw new Error("K1D_POSITIVE_RETRY_NOT_AUTHORIZED");

    const service = createPlannerProviderIntegrationService({ store: options.store, provider: options.provider });
    result = await service.retryPlannerRequest({ projectId: automationProjectId, actionIntentId: intent.intentId });
    const deadline = Date.now() + Math.max(5_000, Math.min(options.timeoutMs, 300_000));
    while (result.status === "RECOVERY_REQUIRED" && result.actionAttemptId && Date.now() < deadline) {
      if (result.providerRequestRef) {
        const remaining = Math.max(1_000, Math.min(deadline - Date.now(), 30_000));
        await options.requestManager.waitForRequest(result.providerRequestRef, remaining);
      }
      result = await service.reconcilePlannerRequest({ projectId: automationProjectId, actionAttemptId: result.actionAttemptId });
      if (result.status !== "RECOVERY_REQUIRED") break;
    }
    if (result.providerRequestRef) retryRequest = await requestReader(result.providerRequestRef);
    const snapshot = await options.store.snapshot();
    finalSnapshot = snapshot;
    const persistedIntent = snapshot.actionIntents.find((item) => item.intentId === intent.intentId) ?? null;
    const attempts = snapshot.actionAttempts.filter((item) => item.intentId === intent.intentId).sort((left, right) => (left.attemptNumber ?? left.dispatchNumber) - (right.attemptNumber ?? right.dispatchNumber));
    const attempt1 = attempts.find((item) => item.attemptNumber === 1) ?? null;
    const attempt2 = attempts.find((item) => item.attemptNumber === 2) ?? null;
    const receipt2 = attempt2 ? snapshot.actionReceipts.find((item) => item.actionAttemptId === attempt2.actionAttemptId) ?? null : null;
    const plan = persistedIntent?.promotedPlanVersionId ? snapshot.planVersions.find((item) => item.planVersionId === persistedIntent.promotedPlanVersionId) ?? null : null;
    const receipt1 = attempt1 ? snapshot.actionReceipts.find((item) => item.actionAttemptId === attempt1.actionAttemptId) ?? null : null;
    const attempt2Dispatched = retryRequest?.sendStartedAt !== null && retryRequest?.sendStartedAt !== undefined;
    const expectedProviderAttemptIdempotencyRef = attempt2
      ? `k1-d:planner-attempt:${sha256Hex(`${historicalIdempotencyRef}\u0000${attempt2.actionAttemptId}`)}`
      : null;
    const providerAttemptIdempotencyRefMatch = Boolean(expectedProviderAttemptIdempotencyRef
      && retryRequest?.idempotencyKey === expectedProviderAttemptIdempotencyRef);
    actionCorrelation = {
      actionIntentId: persistedIntent?.intentId ?? intent.intentId,
      logicalPlannerRequestId: persistedIntent?.logicalPlannerRequestId ?? logicalPlannerRequestId,
      logicalPlannerRequestIdentitySha256: plannerRequest ? sha256Hex(plannerLogicalIdentity(plannerRequest)) : null,
      historicalPlannerRequestIdentitySha256: historicalPlannerRequest ? sha256Hex(plannerLogicalIdentity(historicalPlannerRequest)) : null,
      historicalLogicalPlannerIdentityMatch: Boolean(plannerRequest && historicalPlannerRequest && plannerLogicalIdentity(plannerRequest) === plannerLogicalIdentity(historicalPlannerRequest)),
      historicalSourceInputIdentityMatch: historicalRequest?.promptSha256 === HISTORICAL_PROMPT_SHA256
        && historicalRequest.promptChars === HISTORICAL_PROMPT_CHARS,
      historicalProviderSemanticIdentityMatch: historicalRequest?.semanticSha256 === HISTORICAL_PROVIDER_SEMANTIC_SHA256,
      postProviderAttemptCount: attempts.length,
      postRealPlannerPromptsTotal: 1 + (attempt2Dispatched ? 1 : 0),
      postNewRealPlannerPromptsThisRedesign: attempt2Dispatched ? 1 : 0,
      actionAttempt1Id: attempt1?.actionAttemptId ?? null,
      actionAttempt2Id: attempt2?.actionAttemptId ?? null,
      policyVersionId: persistedIntent?.policyVersionId ?? null,
      idempotencyRef: persistedIntent?.idempotencyRef ?? historicalIdempotencyRef,
      providerAttemptIdempotencyRef: retryRequest?.idempotencyKey ?? null,
      expectedProviderAttemptIdempotencyRef,
      providerAttemptIdempotencyRefDistinct: Boolean(retryRequest?.idempotencyKey && retryRequest.idempotencyKey !== historicalIdempotencyRef),
      providerAttemptIdempotencyRefMatch,
      providerTargetRef,
      providerRequestRef: result.providerRequestRef,
      providerRequestExternalRef: result.providerRequestExternalRef,
      providerObservationExternalRef: result.providerObservationExternalRef,
      receiptId: receipt2?.receiptId ?? result.receiptId,
      receiptStatus: receipt2?.status ?? null,
      receiptOutcomeCertainty: receipt2?.outcomeCertainty ?? null,
      receiptReconcileState: receipt2?.reconcileState ?? null,
      targetIdentityMatch: chatIdentityMatches(retryRequest),
      providerRequestIdentityMatch: Boolean(result.providerRequestRef && retryRequest?.requestId === result.providerRequestRef),
      providerObservationIdentityMatch: Boolean(result.providerObservationExternalRef && receipt2?.providerObservationRef === result.providerObservationExternalRef),
      attempt1ReceiptId: receipt1?.receiptId ?? null,
    };
    statusQuery = await service.plannerStatus({ projectId: automationProjectId, actionIntentId: intent.intentId });
    resultQuery = await service.plannerResult({ projectId: automationProjectId, actionIntentId: intent.intentId });
    const promotionCount = snapshot.auditEvents.filter((event) => event.eventType === "PLANNER_PLAN_PROMOTED" && event.correlationId === logicalPlannerRequestId).length;
    if (result.status === "PLAN_READY" && result.planVersion) {
      persistence = { attempted: true, reopened: false, beforeActivePlanVersionId: snapshot.automationProjects.find((item) => item.projectId === automationProjectId)?.activePlanVersionId ?? null };
      const databasePath = options.store.filePath;
      await options.store.close();
      storeClosed = true;
      const reopened = new AutomationStore(databasePath);
      const reopenedProject = await reopened.get("automationProjects", automationProjectId);
      const reopenedPlan = await reopened.getCurrentPlanVersion(automationProjectId);
      persistence = {
        attempted: true,
        reopened: true,
        activePlanVersionId: reopenedProject?.activePlanVersionId ?? null,
        planVersionId: reopenedPlan?.planVersionId ?? null,
        planStatus: reopenedPlan?.status ?? null,
        requirementVersionId: reopenedPlan?.requirementVersionId ?? null,
        activePointerMatches: reopenedProject?.activePlanVersionId === result.planVersion.planVersionId,
        planSurvivedRestart: reopenedPlan?.planVersionId === result.planVersion.planVersionId,
      };
      await reopened.close();
    }
    const attempt2Submitted = retryRequest?.submittedAt !== null && retryRequest?.submittedAt !== undefined;
    const correlationClosed = actionCorrelation.targetIdentityMatch === true
      && actionCorrelation.providerRequestIdentityMatch === true
      && actionCorrelation.providerObservationIdentityMatch === true
      && actionCorrelation.providerAttemptIdempotencyRefMatch === true
      && actionCorrelation.historicalLogicalPlannerIdentityMatch === true
      && actionCorrelation.historicalSourceInputIdentityMatch === true
      && actionCorrelation.historicalProviderSemanticIdentityMatch === true;
    const persistenceClosed = persistence.activePointerMatches === true && persistence.planSurvivedRestart === true;
    const queryClosed = result.status === "PLAN_READY"
      && statusQuery.planVersionId === result.planVersion?.planVersionId
      && resultQuery.planVersion?.planVersionId === result.planVersion?.planVersionId;
    const promotions = promotionCount;
    const validPass = result.status === "PLAN_READY"
      && attempt2Submitted
      && attempt2?.attemptNumber === 2
      && attempt2.plannerResultClassification === "VALID_OUTPUT"
      && attempts.length === 2
      && promotions === 1
      && correlationClosed
      && persistenceClosed
      && queryClosed;
    if (!validPass && result.status === "PLAN_READY") throw new Error("K1D_POSITIVE_RETRY_POSTCONDITION_FAILED");
  } catch (caught) {
    error = boundedError(caught, [promptForRedaction]);
  } finally {
    targetLifecycle = [
      ...bindingLifecycle,
      ...(options.getTargetIdentityTrace?.().map((item) => ({ ...item })) ?? []),
    ];
    if (inputRegistration) options.inputRefs.release(inputRegistration.inputRef, historicalIdempotencyRef);
    if (!storeClosed) await options.store.close().catch(() => undefined);
  }

  const snapshot = finalSnapshot;
  const attempts = snapshot?.actionAttempts.filter((item) => item.intentId === historicalActionIntentId).sort((left, right) => (left.attemptNumber ?? left.dispatchNumber) - (right.attemptNumber ?? right.dispatchNumber)) ?? [];
  const attempt1 = attempts.find((item) => item.attemptNumber === 1) ?? null;
  const attempt2 = attempts.find((item) => item.attemptNumber === 2) ?? null;
  const receipt1 = attempt1 && snapshot ? snapshot.actionReceipts.find((item) => item.actionAttemptId === attempt1.actionAttemptId) ?? null : null;
  const receipt2 = attempt2 && snapshot ? snapshot.actionReceipts.find((item) => item.actionAttemptId === attempt2.actionAttemptId) ?? null : null;
  const promotionCount = snapshot ? snapshot.auditEvents.filter((event) => event.eventType === "PLANNER_PLAN_PROMOTED" && event.correlationId === logicalPlannerRequestId).length : 0;
  const attempt2Dispatched = retryRequest?.sendStartedAt !== null && retryRequest?.sendStartedAt !== undefined;
  const attempt2Submitted = retryRequest?.submittedAt !== null && retryRequest?.submittedAt !== undefined;
  const observedResult = resultStatus(result, retryRequest);
  const completedAt = now();
  const provenance = evidenceProvenance(options.provenance, completedAt);
  const finalResult: StageK1DEvidence["result"] = error?.code === "K1D_POSITIVE_RETRY_NOT_AUTHORIZED"
    ? "BLOCKED"
    : observedResult === "PASS_REAL"
      && attempt2Submitted
      && attempts.length === 2
      && promotionCount === 1
      && persistence.activePointerMatches === true
      && persistence.planSurvivedRestart === true
      && provenance.verified
      ? "PASS_REAL"
      : observedResult === "BLOCKED" ? "BLOCKED" : "FIX_REQUIRED";
  const evidence: StageK1DEvidence = {
    stage: STAGE,
    result: finalResult,
    startedAt,
    completedAt,
    providerProjectId,
    automationProjectId,
    plannerTarget: {
      providerTargetRef,
      workflowRole: PLANNER_ROLE,
      resolution: targetResolution ? { provider: targetResolution.provider, status: targetResolution.status, capability: targetResolution.capability } : {},
      capabilities: capabilities.map((item) => ({ provider: item.provider, code: item.code, detail: item.detail ?? null })),
      boundChatUrlSha256,
    },
    requirement: {
      requirementVersionId,
      payloadSha256: requirementPayloadSha256,
      status: requirementVersionId ? "CONFIRMED" : null,
      canonicalPayloadLogged: false,
    },
    plannerRequest: {
      operation: plannerRequest?.operation ?? null,
      idempotencyRef: historicalIdempotencyRef,
      inputRef: inputRegistration?.inputRef ?? null,
      inputSha256: inputRegistration?.sha256 ?? null,
      promptChars: inputRegistration?.length ?? null,
      logicalPlannerRequestId,
      maxProviderAttempts: 2,
      providerAttempts: attempts.length,
      attempt1: summarizePlannerAttempt(attempt1, receipt1),
      attempt2: summarizePlannerAttempt(attempt2, receipt2),
      requestBefore: historicalRequest ? { ...summarizeRequest(historicalRequest)! } : null,
      requestAfter: retryRequest ? { ...summarizeRequest(retryRequest)! } : null,
      realPlannerPrompts: 1 + (attempt2Dispatched ? 1 : 0),
      newRealPlannerPromptsThisRedesign: attempt2Dispatched ? 1 : 0,
      planPromotions: promotionCount,
      duplicatePlanPromotion: 0,
      retryBudgetExhausted: attempts.length >= 2,
      existingProviderRequestReused: historicalRequest !== null,
      duplicatePlannerPrompt: 0,
      blindResend: false,
    },
    actionCorrelation: { ...preconditionSnapshot, ...actionCorrelation },
    providerResult: {
      status: result?.status ?? null,
      errorCode: result?.errorCode ?? null,
      errorMessage: result?.errorMessage ? result.errorMessage.slice(0, 512) : null,
      providerRequestRef: result?.providerRequestRef ?? null,
      receiptId: result?.receiptId ?? null,
      planVersionId: result?.planVersion?.planVersionId ?? null,
      planVersion: result?.planVersion?.version ?? null,
      validation: validationSummary(result?.validation ?? null),
      statusQuery: statusQuery ? { ...statusQuery } : null,
      resultQuery: resultQuery ? { actionIntentId: resultQuery.actionIntentId, actionAttemptId: resultQuery.actionAttemptId, receiptStatus: resultQuery.receipt?.status ?? null, planVersionId: resultQuery.planVersion?.planVersionId ?? null } : null,
    },
    targetLifecycle,
    persistence,
    provenance,
    safety: {
      executedSteps: false,
      newNativeThreads: 0,
      verifierStarted: false,
      schedulerStarted: false,
      rawPromptLogged: false,
      rawResponseLogged: false,
    },
    error,
  };
  await writeEvidence(options.outputPath, evidence);
  return evidence;
}
