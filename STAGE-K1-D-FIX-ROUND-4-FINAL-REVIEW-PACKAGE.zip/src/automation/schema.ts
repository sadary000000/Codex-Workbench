import { createHash } from "node:crypto";
import {
  AUTOMATION_SCHEMA_VERSION,
  type AutomationDocument,
  type AutomationProjectLifecycle,
  type BoundedMetadata,
  type ExternalRefKind,
  type RequirementOriginSource,
  type RequirementOriginType,
  type ResourceClaimMode,
  type ResourceClaimState,
  type ResourceType,
  type SideEffectClass,
  type StepKind,
} from "./types.ts";
import { canonicalizeJson, computeActionSemanticSha256, sha256Hex } from "./canonical.ts";
import { RequirementDomainError, validateRequirementDomain } from "./requirement-domain.ts";
import { createEvidenceCorrelation } from "./evidence-correlation.ts";
import { assertIntentAttemptPolicyPin } from "./stable-identity.ts";

const PROJECT_LIFECYCLES = new Set<AutomationProjectLifecycle>([
  "DRAFT",
  "ALIGNING_REQUIREMENTS",
  "REQUIREMENTS_CONFIRMED",
  "PLANNING",
  "READY",
  "RUNNING",
  "PAUSED",
  "BLOCKED",
  "COMPLETED",
  "FAILED",
  "CANCELLED",
]);
const SIDE_EFFECT_CLASSES = new Set<SideEffectClass>(["PURE", "IDEMPOTENT", "RECONCILABLE", "NON_REPEATABLE"]);
const STEP_KINDS = new Set<StepKind>(["PLANNER_STEP", "SYSTEM_STEP"]);
const EXTERNAL_REF_KINDS = new Set<ExternalRefKind>([
  "NATIVE_THREAD",
  "NATIVE_TURN",
  "WEBGPT_REQUEST",
  "WEBGPT_PROVIDER_REQUEST",
  "WEBGPT_PROVIDER_OBSERVATION",
  "WEBGPT_RESOURCE_LEASE",
  "WEBGPT_ROLE_BINDING",
  "WORKBENCH_PROJECT",
  "GIT_COMMIT",
  "ARTIFACT",
  "HARDWARE_DEVICE",
  "OTHER",
]);
const RESOURCE_TYPES = new Set<ResourceType>([
  "WEBGPT_BROWSER",
  "WORKSPACE_WRITER",
  "HARDWARE",
  "VIVADO",
  "CODEX_EXECUTOR",
  "USER_APPROVAL",
  "CUSTOM",
]);
const RESOURCE_MODES = new Set<ResourceClaimMode>(["EXCLUSIVE", "SHARED"]);
const RESOURCE_STATES = new Set<ResourceClaimState>(["REQUESTED", "ACQUIRED", "RELEASED", "FAILED"]);
const SENSITIVE_KEY = /(?:prompt|response|transcript|cookie|token|authorization|password|credential|secret|stdout|stderr|raw.?body)/i;
const MAX_STRING = 4_096;
const MAX_GOAL = 8_192;
const MAX_METADATA = 32;
const STAGE_DETAIL_LEVELS = new Set(["OUTLINE", "DETAILED"]);
const STEP_RUNTIME_LIFECYCLES = new Set(["NOT_STARTED", "READY", "RUNNING", "VERIFYING", "REVIEWING", "TERMINAL"]);
const STEP_RUNTIME_WAIT_REASONS = new Set(["NONE", "RESOURCE", "HUMAN", "EXTERNAL", "USER_CONTROL", "RATE_LIMIT"]);
const REQUIREMENT_ORIGIN_TYPES = new Set<RequirementOriginType>(["INITIAL", "REVISION", "DISCOVERY", "RECOVERY", "IMPORT"]);
const REQUIREMENT_ORIGIN_SOURCES = new Set<RequirementOriginSource>(["USER", "WEBGPT", "PROJECT_EVIDENCE", "SYSTEM", "IMPORT"]);
const PLANNER_OPERATIONS = new Set(["PLAN_REQUIREMENT", "DETAIL_STAGE"]);
const PLANNER_LOGICAL_STATES = new Set(["REQUESTED", "ACTIVE", "VALIDATED", "PROMOTED", "FAILED"]);
const PLANNER_RESULT_CLASSIFICATIONS = new Set(["VALID_OUTPUT", "INVALID_OUTPUT_RETRYABLE", "INVALID_OUTPUT_NON_RETRYABLE", "UNKNOWN_AFTER_SIDE_EFFECT", "PRE_DISPATCH_FAILED"]);
const OUTCOME_CERTAINTIES = new Set(["NOT_DISPATCHED", "ACCEPTED_UNKNOWN_RESULT", "RESULT_OBSERVED", "TERMINAL_CONFIRMED", "TERMINAL_FAILED", "ABANDONED_WITH_UNKNOWN_OUTCOME"]);

export class AutomationSchemaError extends Error {
  readonly code: "AUTOMATION_SCHEMA_INVALID" | "AUTOMATION_SCHEMA_VERSION_UNSUPPORTED";

  constructor(message: string, code: "AUTOMATION_SCHEMA_INVALID" | "AUTOMATION_SCHEMA_VERSION_UNSUPPORTED" = "AUTOMATION_SCHEMA_INVALID") {
    super(message);
    this.code = code;
    this.name = "AutomationSchemaError";
  }
}

function record(value: unknown): Record<string, unknown> {
  if (!value || typeof value !== "object" || Array.isArray(value)) throw new AutomationSchemaError("Automation database root must be an object.");
  return value as Record<string, unknown>;
}

function array(value: unknown, field: string): unknown[] {
  if (!Array.isArray(value)) throw new AutomationSchemaError(`${field} must be an array.`);
  return value;
}

function string(value: unknown, field: string, max = MAX_STRING): string {
  if (typeof value !== "string" || value.length === 0 || value.length > max) throw new AutomationSchemaError(`${field} must be a bounded non-empty string.`);
  return value;
}

function optionalString(value: unknown, field: string, max = MAX_STRING): string | null {
  if (value === null) return null;
  return string(value, field, max);
}

function integer(value: unknown, field: string, minimum = 0): number {
  if (typeof value !== "number" || !Number.isSafeInteger(value) || value < minimum) throw new AutomationSchemaError(`${field} must be a safe integer.`);
  return value;
}

function timestamp(value: unknown, field: string): string {
  const result = string(value, field, 64);
  if (!Number.isFinite(Date.parse(result))) throw new AutomationSchemaError(`${field} must be an ISO timestamp.`);
  return result;
}

function enumValue<T extends string>(value: unknown, field: string, values: ReadonlySet<T>): T {
  if (typeof value !== "string" || !values.has(value as T)) throw new AutomationSchemaError(`${field} contains an unsupported value.`);
  return value as T;
}

function metadata(value: unknown, field: string): BoundedMetadata {
  if (!value || typeof value !== "object" || Array.isArray(value)) throw new AutomationSchemaError(`${field} must be bounded metadata.`);
  const entries = Object.entries(value as Record<string, unknown>);
  if (entries.length > MAX_METADATA) throw new AutomationSchemaError(`${field} has too many entries.`);
  const output: BoundedMetadata = {};
  const typedPolicyKeys = new Set(["maxPromptDispatches", "maxRepairDispatches", "maxRetryDispatches", "maxNewChatDispatches"]);
  for (const [key, item] of entries) {
    if (!key || key.length > 128 || (SENSITIVE_KEY.test(key) && !(field.startsWith("policyVersions[") && typedPolicyKeys.has(key)))) throw new AutomationSchemaError(`${field} contains a sensitive or invalid key.`);
    if (typeof item !== "string" && typeof item !== "number" && typeof item !== "boolean" && item !== null) {
      throw new AutomationSchemaError(`${field}.${key} must be scalar metadata.`);
    }
    if (typeof item === "string" && item.length > 1_024) throw new AutomationSchemaError(`${field}.${key} is too long.`);
    output[key] = item;
  }
  return output;
}

function entityId(item: Record<string, unknown>, key: string, index: number): string {
  return string(item[key], `${key}[${index}].${key}`, 256);
}

function validateUniqueIds(items: unknown[], key: string, table: string): void {
  const ids = new Set<string>();
  items.forEach((value, index) => {
    const item = record(value);
    const id = entityId(item, key, index);
    if (ids.has(id)) throw new AutomationSchemaError(`${table} contains duplicate identity ${id}.`);
    ids.add(id);
  });
}

function validateProject(item: Record<string, unknown>, index: number): void {
  string(item.projectId, `automationProjects[${index}].projectId`, 256);
  string(item.name, `automationProjects[${index}].name`, 256);
  enumValue(item.lifecycle, `automationProjects[${index}].lifecycle`, PROJECT_LIFECYCLES);
  timestamp(item.createdAt, `automationProjects[${index}].createdAt`);
  timestamp(item.updatedAt, `automationProjects[${index}].updatedAt`);
  optionalString(item.activeRequirementVersionId, `automationProjects[${index}].activeRequirementVersionId`, 256);
  optionalString(item.activePlanVersionId, `automationProjects[${index}].activePlanVersionId`, 256);
  optionalString(item.policyVersionId, `automationProjects[${index}].policyVersionId`, 256);
  integer(item.revision, `automationProjects[${index}].revision`);
}

function validateVersions(document: Record<string, unknown>): void {
  const origins = array(document.requirementOrigins, "requirementOrigins");
  validateUniqueIds(origins, "requirementOriginId", "requirementOrigins");
  origins.forEach((value, index) => {
    const item = record(value);
    const field = `requirementOrigins[${index}]`;
    string(item.requirementOriginId, `${field}.requirementOriginId`, 256);
    string(item.projectId, `${field}.projectId`, 256);
    enumValue(item.originType, `${field}.originType`, REQUIREMENT_ORIGIN_TYPES);
    enumValue(item.source, `${field}.source`, REQUIREMENT_ORIGIN_SOURCES);
    if (item.sourceRef !== null && item.sourceRef !== undefined) {
      const sourceRef = string(item.sourceRef, `${field}.sourceRef`, 256);
      if (/^https?:\/\//i.test(sourceRef)) throw new AutomationSchemaError(`${field}.sourceRef must be an opaque reference, not a URL.`);
    }
    timestamp(item.createdAt, `${field}.createdAt`);
  });

  const requirements = array(document.requirementVersions, "requirementVersions");
  validateUniqueIds(requirements, "requirementVersionId", "requirementVersions");
  const requirementVersionsByProject = new Set<string>();
  const requirementRootByProject = new Set<string>();
  requirements.forEach((value, index) => {
    const item = record(value);
    string(item.requirementVersionId, `requirementVersions[${index}].requirementVersionId`, 256);
    string(item.projectId, `requirementVersions[${index}].projectId`, 256);
    integer(item.version, `requirementVersions[${index}].version`, 1);
    const projectVersion = `${item.projectId}\u0000${item.version}`;
    if (requirementVersionsByProject.has(projectVersion)) throw new AutomationSchemaError(`requirementVersions contains duplicate project/version ${projectVersion}.`);
    requirementVersionsByProject.add(projectVersion);
    if (item.version === 1) {
      if (requirementRootByProject.has(item.projectId as string)) throw new AutomationSchemaError(`requirementVersions contains multiple version 1 roots for project ${item.projectId}.`);
      requirementRootByProject.add(item.projectId as string);
    }
    enumValue(item.status, `requirementVersions[${index}].status`, new Set(["DRAFT", "CONFIRMED", "ACTIVE", "SUPERSEDED"]));
    string(item.originRef, `requirementVersions[${index}].originRef`, 256);
    optionalString(item.contentRef, `requirementVersions[${index}].contentRef`, 256);
    optionalString(item.structuredPayloadRef, `requirementVersions[${index}].structuredPayloadRef`, 256);
    let canonicalPayload: string;
    try {
      canonicalPayload = canonicalizeJson(string(item.canonicalPayload, `requirementVersions[${index}].canonicalPayload`, 32 * 1024), `requirementVersions[${index}].canonicalPayload`);
    } catch (error) {
      throw new AutomationSchemaError(error instanceof Error ? error.message : "Requirement canonical payload is invalid.");
    }
    const payloadSha256 = string(item.payloadSha256, `requirementVersions[${index}].payloadSha256`, 128);
    if (payloadSha256 !== sha256Hex(canonicalPayload)) throw new AutomationSchemaError(`requirementVersions[${index}].payloadSha256 does not match canonicalPayload.`);
    timestamp(item.createdAt, `requirementVersions[${index}].createdAt`);
    optionalString(item.confirmedAt, `requirementVersions[${index}].confirmedAt`, 64);
    optionalString(item.supersedes, `requirementVersions[${index}].supersedes`, 256);
  });

  const plans = array(document.planVersions, "planVersions");
  validateUniqueIds(plans, "planVersionId", "planVersions");
  const planVersionsByProject = new Set<string>();
  plans.forEach((value, index) => {
    const item = record(value);
    string(item.planVersionId, `planVersions[${index}].planVersionId`, 256);
    string(item.projectId, `planVersions[${index}].projectId`, 256);
    string(item.requirementVersionId, `planVersions[${index}].requirementVersionId`, 256);
    integer(item.version, `planVersions[${index}].version`, 1);
    const projectVersion = `${item.projectId}\u0000${item.version}`;
    if (planVersionsByProject.has(projectVersion)) throw new AutomationSchemaError(`planVersions contains duplicate project/version ${projectVersion}.`);
    planVersionsByProject.add(projectVersion);
    enumValue(item.status, `planVersions[${index}].status`, new Set(["DRAFT", "ACTIVE", "SUPERSEDED"]));
    if (item.createdBy !== undefined) string(item.createdBy, `planVersions[${index}].createdBy`, 256);
    if (item.origin !== undefined) string(item.origin, `planVersions[${index}].origin`, 256);
    if (item.canonicalPayload !== undefined) {
      let canonicalPayload: string;
      try {
        canonicalPayload = canonicalizeJson(string(item.canonicalPayload, `planVersions[${index}].canonicalPayload`, 32 * 1024), `planVersions[${index}].canonicalPayload`);
      } catch (error) {
        throw new AutomationSchemaError(error instanceof Error ? error.message : "Plan canonical payload is invalid.");
      }
      const payloadSha256 = string(item.payloadSha256, `planVersions[${index}].payloadSha256`, 128);
      if (payloadSha256 !== sha256Hex(canonicalPayload)) throw new AutomationSchemaError(`planVersions[${index}].payloadSha256 does not match canonicalPayload.`);
    } else if (item.payloadSha256 !== undefined) {
      throw new AutomationSchemaError(`planVersions[${index}].payloadSha256 requires canonicalPayload.`);
    }
    if (item.requirementPayloadSha256 !== undefined && item.requirementPayloadSha256 !== null) string(item.requirementPayloadSha256, `planVersions[${index}].requirementPayloadSha256`, 128);
    if (item.planningMode !== undefined && item.planningMode !== "JIT") throw new AutomationSchemaError(`planVersions[${index}].planningMode is unsupported.`);
    if (item.plannerRole !== undefined && item.plannerRole !== "PLANNER") throw new AutomationSchemaError(`planVersions[${index}].plannerRole is unsupported.`);
    if (item.plannerChatRef !== undefined && item.plannerChatRef !== null) string(item.plannerChatRef, `planVersions[${index}].plannerChatRef`, 2_000);
    optionalString(item.currentStageId ?? null, `planVersions[${index}].currentStageId`, 256);
    timestamp(item.createdAt, `planVersions[${index}].createdAt`);
    optionalString(item.supersedes, `planVersions[${index}].supersedes`, 256);
  });

  const stages = array(document.stageSpecs, "stageSpecs");
  validateUniqueIds(stages, "stageSpecId", "stageSpecs");
  stages.forEach((value, index) => {
    const item = record(value);
    string(item.stageSpecId, `stageSpecs[${index}].stageSpecId`, 256);
    string(item.planVersionId, `stageSpecs[${index}].planVersionId`, 256);
    string(item.stageKey, `stageSpecs[${index}].stageKey`, 256);
    if (item.name !== undefined) string(item.name, `stageSpecs[${index}].name`, 256);
    const objective = item.objective === undefined ? null : string(item.objective, `stageSpecs[${index}].objective`, MAX_GOAL);
    integer(item.specVersion, `stageSpecs[${index}].specVersion`, 1);
    enumValue(item.status, `stageSpecs[${index}].status`, new Set(["DRAFT", "ACTIVE", "SUPERSEDED"]));
    integer(item.ordinal, `stageSpecs[${index}].ordinal`, 0);
    const goal = string(item.goal, `stageSpecs[${index}].goal`, MAX_GOAL);
    if (objective !== null && objective !== goal) throw new AutomationSchemaError(`stageSpecs[${index}].objective must match goal.`);
    if (item.dependsOn !== undefined) {
      const refs = array(item.dependsOn, `stageSpecs[${index}].dependsOn`);
      if (refs.length > 64) throw new AutomationSchemaError(`stageSpecs[${index}].dependsOn has too many entries.`);
      refs.forEach((ref, refIndex) => string(ref, `stageSpecs[${index}].dependsOn[${refIndex}]`, 4_096));
    }
    for (const field of ["acceptanceCriteria", "assumptions", "risks"]) {
      if (item[field] === undefined) continue;
      const values = array(item[field], `stageSpecs[${index}].${field}`);
      if (values.length > 64) throw new AutomationSchemaError(`stageSpecs[${index}].${field} has too many entries.`);
      values.forEach((entry, entryIndex) => string(entry, `stageSpecs[${index}].${field}[${entryIndex}]`, MAX_GOAL));
    }
    if (item.detailLevel !== undefined) enumValue(item.detailLevel, `stageSpecs[${index}].detailLevel`, STAGE_DETAIL_LEVELS);
    timestamp(item.createdAt, `stageSpecs[${index}].createdAt`);
    optionalString(item.supersedes, `stageSpecs[${index}].supersedes`, 256);
  });

  const steps = array(document.stepSpecs, "stepSpecs");
  validateUniqueIds(steps, "stepSpecId", "stepSpecs");
  steps.forEach((value, index) => {
    const item = record(value);
    string(item.stepSpecId, `stepSpecs[${index}].stepSpecId`, 256);
    string(item.stageSpecId, `stepSpecs[${index}].stageSpecId`, 256);
    string(item.stepKey, `stepSpecs[${index}].stepKey`, 256);
    integer(item.specVersion, `stepSpecs[${index}].specVersion`, 1);
    enumValue(item.kind, `stepSpecs[${index}].kind`, STEP_KINDS);
    if (item.ordinal !== undefined) integer(item.ordinal, `stepSpecs[${index}].ordinal`, 0);
    const objective = item.objective === undefined ? null : string(item.objective, `stepSpecs[${index}].objective`, MAX_GOAL);
    const goal = string(item.goal, `stepSpecs[${index}].goal`, MAX_GOAL);
    if (objective !== null && objective !== goal) throw new AutomationSchemaError(`stepSpecs[${index}].objective must match goal.`);
    for (const field of ["inputs", "expectedOutputs", "acceptanceCriteria", "assumptions", "constraints"]) {
      if (item[field] === undefined) continue;
      const values = array(item[field], `stepSpecs[${index}].${field}`);
      if (values.length > 64) throw new AutomationSchemaError(`stepSpecs[${index}].${field} has too many entries.`);
      values.forEach((entry, entryIndex) => string(entry, `stepSpecs[${index}].${field}[${entryIndex}]`, MAX_GOAL));
    }
    enumValue(item.riskClass, `stepSpecs[${index}].riskClass`, new Set(["LOW", "MEDIUM", "HIGH"]));
    enumValue(item.sideEffectClass, `stepSpecs[${index}].sideEffectClass`, new Set(["PURE", "IDEMPOTENT", "RECONCILABLE", "NON_REPEATABLE"]));
    enumValue(item.specStatus, `stepSpecs[${index}].specStatus`, new Set(["ACTIVE", "SUPERSEDED"]));
    timestamp(item.createdAt, `stepSpecs[${index}].createdAt`);
    optionalString(item.supersedes, `stepSpecs[${index}].supersedes`, 256);
  });

  const runtimes = array(document.stepRuntimes, "stepRuntimes");
  validateUniqueIds(runtimes, "stepRuntimeId", "stepRuntimes");
  runtimes.forEach((value, index) => {
    const item = record(value);
    string(item.stepRuntimeId, `stepRuntimes[${index}].stepRuntimeId`, 256);
    string(item.stepSpecId, `stepRuntimes[${index}].stepSpecId`, 256);
    enumValue(item.lifecycle, `stepRuntimes[${index}].lifecycle`, STEP_RUNTIME_LIFECYCLES);
    if (item.terminalResult !== null) enumValue(item.terminalResult, `stepRuntimes[${index}].terminalResult`, new Set(["COMPLETED", "FAILED", "BLOCKED", "CANCELLED", "SUPERSEDED", "SKIPPED"]));
    enumValue(item.waitReason, `stepRuntimes[${index}].waitReason`, STEP_RUNTIME_WAIT_REASONS);
    optionalString(item.currentAttemptId, `stepRuntimes[${index}].currentAttemptId`, 256);
    integer(item.revision, `stepRuntimes[${index}].revision`);
    timestamp(item.createdAt, `stepRuntimes[${index}].createdAt`);
    timestamp(item.updatedAt, `stepRuntimes[${index}].updatedAt`);
  });
}

function validateCommonTables(document: Record<string, unknown>): void {
  const tables: Array<[string, string]> = [
    ["executionAttempts", "attemptId"],
    ["stepRuntimes", "stepRuntimeId"],
    ["actionIntents", "intentId"],
    ["actionAttempts", "actionAttemptId"],
    ["actionReceipts", "receiptId"],
    ["auditEvents", "eventId"],
    ["checkpoints", "checkpointId"],
    ["externalRefs", "externalRefId"],
    ["evidences", "evidenceId"],
    ["artifactRefs", "artifactRefId"],
    ["resourceClaims", "resourceClaimId"],
    ["workspaceSnapshots", "workspaceSnapshotId"],
    ["policyVersions", "policyVersionId"],
  ];
  for (const [table, key] of tables) validateUniqueIds(array(document[table], table), key, table);

  const attempts = array(document.executionAttempts, "executionAttempts");
  attempts.forEach((value, index) => {
    const item = record(value);
    string(item.attemptId, `executionAttempts[${index}].attemptId`, 256);
    string(item.projectId, `executionAttempts[${index}].projectId`, 256);
    string(item.stageSpecId, `executionAttempts[${index}].stageSpecId`, 256);
    string(item.stepSpecId, `executionAttempts[${index}].stepSpecId`, 256);
    integer(item.attemptNumber, `executionAttempts[${index}].attemptNumber`, 1);
    enumValue(item.lifecycle, `executionAttempts[${index}].lifecycle`, new Set(["CREATED", "RUNNING", "COMPLETED", "FAILED", "BLOCKED", "CANCELLED", "UNCERTAIN", "RECOVERY_REQUIRED"]));
    optionalString(item.startedAt, `executionAttempts[${index}].startedAt`, 64);
    optionalString(item.completedAt, `executionAttempts[${index}].completedAt`, 64);
    if (item.terminalResult !== null) enumValue(item.terminalResult, `executionAttempts[${index}].terminalResult`, new Set(["COMPLETED", "FAILED", "BLOCKED", "CANCELLED", "SUPERSEDED", "SKIPPED"]));
    timestamp(item.createdAt, `executionAttempts[${index}].createdAt`);
  });

  const intents = array(document.actionIntents, "actionIntents");
  const idempotencyKeys = new Set<string>();
  intents.forEach((value, index) => {
    const item = record(value);
    string(item.intentId, `actionIntents[${index}].intentId`, 256);
    string(item.projectId, `actionIntents[${index}].projectId`, 256);
    optionalString(item.stageSpecId, `actionIntents[${index}].stageSpecId`, 256);
    optionalString(item.stepSpecId, `actionIntents[${index}].stepSpecId`, 256);
    optionalString(item.attemptId, `actionIntents[${index}].attemptId`, 256);
    string(item.actionType, `actionIntents[${index}].actionType`, 256);
    optionalString(item.targetRef, `actionIntents[${index}].targetRef`, 256);
    enumValue(item.sideEffectClass, `actionIntents[${index}].sideEffectClass`, new Set(["PURE", "IDEMPOTENT", "RECONCILABLE", "NON_REPEATABLE"]));
    optionalString(item.payloadRef, `actionIntents[${index}].payloadRef`, 256);
    if (item.actionType === "REQUIREMENT_ALIGNMENT" && item.payloadRef !== null && item.payloadRef !== undefined && !/^automation-input-v1:[a-f0-9]{64}$/i.test(item.payloadRef as string)) {
      throw new AutomationSchemaError(`actionIntents[${index}].payloadRef must be an opaque process-owned InputRef.`);
    }
    optionalString(item.payloadHash, `actionIntents[${index}].payloadHash`, 128);
    if (item.plannerRequestCanonical !== undefined && item.plannerRequestCanonical !== null) {
      const plannerRequestCanonical = optionalString(item.plannerRequestCanonical, `actionIntents[${index}].plannerRequestCanonical`, 32 * 1024);
      if (plannerRequestCanonical !== null) canonicalizeJson(plannerRequestCanonical, `actionIntents[${index}].plannerRequestCanonical`);
    }
    if (item.actionType === "PLANNER_REQUEST" && (item.plannerRequestCanonical === undefined || item.plannerRequestCanonical === null)) {
      throw new AutomationSchemaError(`actionIntents[${index}].plannerRequestCanonical is required for PLANNER_REQUEST.`);
    }
    if (item.actionType !== "PLANNER_REQUEST" && item.plannerRequestCanonical !== undefined && item.plannerRequestCanonical !== null) {
      throw new AutomationSchemaError(`actionIntents[${index}].plannerRequestCanonical is only allowed for PLANNER_REQUEST.`);
    }
    const executionOptions = metadata(item.executionOptions, `actionIntents[${index}].executionOptions`);
    const semanticSha256 = string(item.semanticSha256, `actionIntents[${index}].semanticSha256`, 128);
    const expectedSemanticSha256 = computeActionSemanticSha256({ actionType: item.actionType as string, targetRef: (item.targetRef ?? null) as string | null, sideEffectClass: item.sideEffectClass as string, payloadRef: (item.payloadRef ?? null) as string | null, payloadHash: (item.payloadHash ?? null) as string | null, executionOptions, expectedOutcomeRef: (item.expectedOutcomeRef ?? null) as string | null });
    if (semanticSha256 !== expectedSemanticSha256) throw new AutomationSchemaError(`actionIntents[${index}].semanticSha256 does not match the canonical action descriptor.`);
    optionalString(item.idempotencyRef, `actionIntents[${index}].idempotencyRef`, 256);
    optionalString(item.policyVersionId ?? null, `actionIntents[${index}].policyVersionId`, 256);
    const plannerFields = [
      "logicalPlannerRequestId",
      "plannerRequirementVersionId",
      "plannerRequirementPayloadSha256",
      "plannerOperation",
      "plannerMaxProviderAttempts",
      "plannerState",
      "promotedPlanVersionId",
    ];
    const hasPlannerFields = plannerFields.some((field) => item[field] !== undefined && item[field] !== null);
    if (item.logicalPlannerRequestId !== undefined && item.logicalPlannerRequestId !== null) optionalString(item.logicalPlannerRequestId, `actionIntents[${index}].logicalPlannerRequestId`, 256);
    if (item.plannerRequirementVersionId !== undefined && item.plannerRequirementVersionId !== null) optionalString(item.plannerRequirementVersionId, `actionIntents[${index}].plannerRequirementVersionId`, 256);
    if (item.plannerRequirementPayloadSha256 !== undefined && item.plannerRequirementPayloadSha256 !== null) {
      const requirementHash = string(item.plannerRequirementPayloadSha256, `actionIntents[${index}].plannerRequirementPayloadSha256`, 64);
      if (!/^[a-f0-9]{64}$/.test(requirementHash)) throw new AutomationSchemaError(`actionIntents[${index}].plannerRequirementPayloadSha256 must be a lowercase SHA-256 hash.`);
    }
    if (item.plannerOperation !== undefined && item.plannerOperation !== null) enumValue(item.plannerOperation, `actionIntents[${index}].plannerOperation`, PLANNER_OPERATIONS);
    if (item.plannerMaxProviderAttempts !== undefined && item.plannerMaxProviderAttempts !== null) integer(item.plannerMaxProviderAttempts, `actionIntents[${index}].plannerMaxProviderAttempts`, 1);
    if (item.plannerState !== undefined && item.plannerState !== null) enumValue(item.plannerState, `actionIntents[${index}].plannerState`, PLANNER_LOGICAL_STATES);
    optionalString(item.promotedPlanVersionId ?? null, `actionIntents[${index}].promotedPlanVersionId`, 256);
    if (item.actionType === "PLANNER_REQUEST") {
      string(item.logicalPlannerRequestId, `actionIntents[${index}].logicalPlannerRequestId`, 256);
      const plannerRequirementVersionId = string(item.plannerRequirementVersionId, `actionIntents[${index}].plannerRequirementVersionId`, 256);
      const plannerRequirementPayloadSha256 = string(item.plannerRequirementPayloadSha256, `actionIntents[${index}].plannerRequirementPayloadSha256`, 64);
      if (!/^[a-f0-9]{64}$/.test(plannerRequirementPayloadSha256)) throw new AutomationSchemaError(`actionIntents[${index}].plannerRequirementPayloadSha256 must be a lowercase SHA-256 hash.`);
      const plannerOperation = enumValue(item.plannerOperation, `actionIntents[${index}].plannerOperation`, PLANNER_OPERATIONS);
      if (integer(item.plannerMaxProviderAttempts, `actionIntents[${index}].plannerMaxProviderAttempts`, 1) !== 2) throw new AutomationSchemaError(`actionIntents[${index}].plannerMaxProviderAttempts must be 2 for K1-D Planner requests.`);
      const plannerState = enumValue(item.plannerState, `actionIntents[${index}].plannerState`, PLANNER_LOGICAL_STATES);
      const promotedPlanVersionId = item.promotedPlanVersionId === null || item.promotedPlanVersionId === undefined
        ? null
        : string(item.promotedPlanVersionId, `actionIntents[${index}].promotedPlanVersionId`, 256);
      if (plannerState === "PROMOTED" && promotedPlanVersionId === null) throw new AutomationSchemaError("A promoted logical PlannerRequest requires promotedPlanVersionId.");
      if (plannerState !== "PROMOTED" && promotedPlanVersionId !== null) throw new AutomationSchemaError("promotedPlanVersionId requires plannerState PROMOTED.");
      let descriptor: Record<string, unknown>;
      try {
        const parsed = JSON.parse(item.plannerRequestCanonical as string) as unknown;
        if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) throw new Error("not an object");
        descriptor = parsed as Record<string, unknown>;
      } catch (error) {
        throw new AutomationSchemaError(`actionIntents[${index}].plannerRequestCanonical is not a valid Planner request descriptor.`);
      }
      const inputRefs = descriptor.inputRefs;
      if (descriptor.projectId !== item.projectId
        || descriptor.requirementVersionId !== plannerRequirementVersionId
        || descriptor.requirementPayloadSha256 !== plannerRequirementPayloadSha256
        || descriptor.operation !== plannerOperation
        || descriptor.providerTargetRef !== item.targetRef
        || !Array.isArray(inputRefs)
        || (inputRefs[0] ?? null) !== (item.payloadRef ?? null)) {
        throw new AutomationSchemaError(`actionIntents[${index}] Planner descriptor does not match its logical-request fields.`);
      }
    } else if (hasPlannerFields) {
      throw new AutomationSchemaError(`actionIntents[${index}] Planner correlation fields are only allowed for PLANNER_REQUEST.`);
    }
    if (item.idempotencyRef !== null) {
      const key = `${item.projectId}\u0000${item.idempotencyRef}`;
      if (idempotencyKeys.has(key)) throw new AutomationSchemaError(`actionIntents[${index}].idempotencyRef is duplicated within a project.`);
      idempotencyKeys.add(key);
    }
    optionalString(item.expectedOutcomeRef, `actionIntents[${index}].expectedOutcomeRef`, 256);
    enumValue(item.state, `actionIntents[${index}].state`, new Set(["PLANNED", "DISPATCH_ELIGIBLE", "DISPATCHING", "DISPATCHED", "COMPLETED", "FAILED", "UNCERTAIN", "RECOVERY_REQUIRED", "CANCELLED"]));
    timestamp(item.createdAt, `actionIntents[${index}].createdAt`);
  });

  const audit = array(document.auditEvents, "auditEvents");
  let previousSequence = 0;
  let previousHash: string | null = null;
  audit.forEach((value, index) => {
    const item = record(value);
    string(item.eventId, `auditEvents[${index}].eventId`, 256);
    string(item.projectId, `auditEvents[${index}].projectId`, 256);
    string(item.entityType, `auditEvents[${index}].entityType`, 256);
    string(item.entityId, `auditEvents[${index}].entityId`, 256);
    string(item.eventType, `auditEvents[${index}].eventType`, 256);
    integer(item.eventVersion, `auditEvents[${index}].eventVersion`, 1);
    integer(item.sequence, `auditEvents[${index}].sequence`, 1);
    if (item.sequence !== previousSequence + 1) throw new AutomationSchemaError(`auditEvents[${index}].sequence must be append-only and contiguous.`);
    previousSequence = item.sequence;
    if (item.aggregateRevision !== null && item.aggregateRevision !== undefined && (!Number.isSafeInteger(item.aggregateRevision) || (item.aggregateRevision as number) < 0)) throw new AutomationSchemaError(`auditEvents[${index}].aggregateRevision must be a non-negative integer or null.`);
    optionalString(item.fromState, `auditEvents[${index}].fromState`, 256);
    optionalString(item.toState, `auditEvents[${index}].toState`, 256);
    const prevHash = item.prevHash === null ? null : string(item.prevHash, `auditEvents[${index}].prevHash`, 128);
    if (prevHash !== previousHash) throw new AutomationSchemaError(`auditEvents[${index}].prevHash does not match the previous event.`);
    const currentHash = string(item.hash, `auditEvents[${index}].hash`, 128);
    const calculatedHash = createHash("sha256").update(JSON.stringify({
      eventId: item.eventId,
      projectId: item.projectId,
      entityType: item.entityType,
      entityId: item.entityId,
      eventType: item.eventType,
      eventVersion: item.eventVersion,
      sequence: item.sequence,
      aggregateRevision: item.aggregateRevision ?? null,
      fromState: item.fromState ?? null,
      toState: item.toState ?? null,
      prevHash: prevHash,
      timestamp: item.timestamp,
      actorType: item.actorType,
      actorRef: item.actorRef,
      boundedPayload: item.boundedPayload,
      correlationId: item.correlationId,
      causationId: item.causationId,
    })).digest("hex");
    if (currentHash !== calculatedHash) throw new AutomationSchemaError(`auditEvents[${index}].hash is invalid.`);
    previousHash = currentHash;
    timestamp(item.timestamp, `auditEvents[${index}].timestamp`);
    enumValue(item.actorType, `auditEvents[${index}].actorType`, new Set(["SYSTEM", "USER", "NATIVE_RUNTIME", "WEBGPT_RUNTIME", "AUTOMATION", "TEST"]));
    optionalString(item.actorRef, `auditEvents[${index}].actorRef`, 256);
    metadata(item.boundedPayload, `auditEvents[${index}].boundedPayload`);
    optionalString(item.correlationId, `auditEvents[${index}].correlationId`, 256);
    optionalString(item.causationId, `auditEvents[${index}].causationId`, 256);
  });

  const actionAttempts = array(document.actionAttempts, "actionAttempts");
  const actionAttemptIdentity = new Set<string>();
  actionAttempts.forEach((value, index) => {
    const item = record(value);
    string(item.actionAttemptId, `actionAttempts[${index}].actionAttemptId`, 256);
    string(item.intentId, `actionAttempts[${index}].intentId`, 256);
    integer(item.dispatchNumber, `actionAttempts[${index}].dispatchNumber`, 1);
    if (item.createdAt !== undefined && item.createdAt !== null) timestamp(item.createdAt, `actionAttempts[${index}].createdAt`);
    optionalString(item.logicalPlannerRequestId ?? null, `actionAttempts[${index}].logicalPlannerRequestId`, 256);
    if (item.attemptNumber !== undefined && item.attemptNumber !== null) {
      integer(item.attemptNumber, `actionAttempts[${index}].attemptNumber`, 1);
      if (item.attemptNumber !== item.dispatchNumber) throw new AutomationSchemaError(`actionAttempts[${index}].attemptNumber must equal dispatchNumber.`);
    }
    optionalString(item.providerTargetRef ?? null, `actionAttempts[${index}].providerTargetRef`, 256);
    if (item.externalSideEffectCertainty !== undefined && item.externalSideEffectCertainty !== null) enumValue(item.externalSideEffectCertainty, `actionAttempts[${index}].externalSideEffectCertainty`, OUTCOME_CERTAINTIES);
    if (item.plannerResultClassification !== undefined && item.plannerResultClassification !== null) enumValue(item.plannerResultClassification, `actionAttempts[${index}].plannerResultClassification`, PLANNER_RESULT_CLASSIFICATIONS);
    enumValue(item.state, `actionAttempts[${index}].state`, new Set(["CREATED", "RUNNING", "COMPLETED", "FAILED", "UNCERTAIN", "RECOVERY_REQUIRED"]));
    optionalString(item.startedAt, `actionAttempts[${index}].startedAt`, 64);
    optionalString(item.completedAt, `actionAttempts[${index}].completedAt`, 64);
    optionalString(item.executorRef, `actionAttempts[${index}].executorRef`, 256);
    optionalString(item.providerRequestRef ?? null, `actionAttempts[${index}].providerRequestRef`, 256);
    optionalString(item.providerObservationRef ?? null, `actionAttempts[${index}].providerObservationRef`, 256);
    optionalString(item.providerSemanticSha256 ?? null, `actionAttempts[${index}].providerSemanticSha256`, 128);
    optionalString(item.policyVersionId ?? null, `actionAttempts[${index}].policyVersionId`, 256);
    enumValue(item.recoveryState, `actionAttempts[${index}].recoveryState`, new Set(["KNOWN_NOT_STARTED", "IN_PROGRESS", "COMPLETED", "FAILED", "UNCERTAIN", "RECOVERY_REQUIRED"]));
    const identity = `${item.intentId}\u0000${item.dispatchNumber}`;
    if (actionAttemptIdentity.has(identity)) throw new AutomationSchemaError(`actionAttempts[${index}] duplicates an existing intentId/dispatchNumber identity.`);
    actionAttemptIdentity.add(identity);
  });

  const receipts = array(document.actionReceipts, "actionReceipts");
  const receiptAttempts = new Set<string>();
  receipts.forEach((value, index) => {
    const item = record(value);
    string(item.receiptId, `actionReceipts[${index}].receiptId`, 256);
    string(item.actionAttemptId, `actionReceipts[${index}].actionAttemptId`, 256);
    if (receiptAttempts.has(item.actionAttemptId as string)) throw new AutomationSchemaError(`actionReceipts[${index}].actionAttemptId already has a receipt.`);
    receiptAttempts.add(item.actionAttemptId as string);
    enumValue(item.status, `actionReceipts[${index}].status`, new Set(["SUCCEEDED", "FAILED", "UNKNOWN"]));
    optionalString(item.externalStatus, `actionReceipts[${index}].externalStatus`, 256);
    if (item.exitCode !== null && (!Number.isSafeInteger(item.exitCode))) throw new AutomationSchemaError(`actionReceipts[${index}].exitCode must be an integer or null.`);
    optionalString(item.resultHash, `actionReceipts[${index}].resultHash`, 128);
    const externalRefs = array(item.externalRefs, `actionReceipts[${index}].externalRefs`);
    externalRefs.forEach((ref, refIndex) => string(ref, `actionReceipts[${index}].externalRefs[${refIndex}]`, 256));
    timestamp(item.createdAt, `actionReceipts[${index}].createdAt`);
    enumValue(item.reconcileState, `actionReceipts[${index}].reconcileState`, new Set(["NOT_REQUIRED", "PENDING", "RECONCILED", "RECOVERY_REQUIRED"]));
    optionalString(item.provider ?? null, `actionReceipts[${index}].provider`, 256);
    optionalString(item.providerRequestRef ?? null, `actionReceipts[${index}].providerRequestRef`, 256);
    optionalString(item.providerObservationRef ?? null, `actionReceipts[${index}].providerObservationRef`, 256);
    const inferredCertainty = item.outcomeCertainty ?? (item.status === "SUCCEEDED" ? "TERMINAL_CONFIRMED" : item.status === "FAILED" ? "TERMINAL_FAILED" : "ABANDONED_WITH_UNKNOWN_OUTCOME");
    enumValue(inferredCertainty, `actionReceipts[${index}].outcomeCertainty`, new Set(["NOT_DISPATCHED", "ACCEPTED_UNKNOWN_RESULT", "RESULT_OBSERVED", "TERMINAL_CONFIRMED", "TERMINAL_FAILED", "ABANDONED_WITH_UNKNOWN_OUTCOME"]));
    const evidenceRefs = item.evidenceRefs === undefined ? [] : array(item.evidenceRefs, `actionReceipts[${index}].evidenceRefs`);
    evidenceRefs.forEach((ref, refIndex) => string(ref, `actionReceipts[${index}].evidenceRefs[${refIndex}]`, 256));
    if (item.status === "UNKNOWN" && item.reconcileState !== "RECOVERY_REQUIRED") throw new AutomationSchemaError(`actionReceipts[${index}] UNKNOWN status requires RECOVERY_REQUIRED reconciliation.`);
  });

  const checkpoints = array(document.checkpoints, "checkpoints");
  checkpoints.forEach((value, index) => {
    const item = record(value);
    string(item.checkpointId, `checkpoints[${index}].checkpointId`, 256);
    string(item.projectId, `checkpoints[${index}].projectId`, 256);
    integer(item.projectRevision, `checkpoints[${index}].projectRevision`);
    for (const key of ["requirementVersionId", "planVersionId", "currentStageSpecId", "currentStepSpecId", "currentStepRuntimeId", "currentAttemptId", "lastActionIntentId", "lastActionReceiptId", "workspaceSnapshotRef", "policyVersionId"]) optionalString(item[key], `checkpoints[${index}].${key}`, 256);
    for (const key of ["resourceClaimRefs", "externalRefs", "evidenceRefs", "issueRefs"]) {
      const refs = array(item[key], `checkpoints[${index}].${key}`);
      refs.forEach((ref, refIndex) => string(ref, `checkpoints[${index}].${key}[${refIndex}]`, 256));
    }
    timestamp(item.createdAt, `checkpoints[${index}].createdAt`);
  });

  const refs = array(document.externalRefs, "externalRefs");
  refs.forEach((value, index) => {
    const item = record(value);
    string(item.externalRefId, `externalRefs[${index}].externalRefId`, 256);
    string(item.projectId, `externalRefs[${index}].projectId`, 256);
    enumValue(item.kind, `externalRefs[${index}].kind`, EXTERNAL_REF_KINDS);
    string(item.provider, `externalRefs[${index}].provider`, 256);
    string(item.opaqueId, `externalRefs[${index}].opaqueId`, 512);
    timestamp(item.createdAt, `externalRefs[${index}].createdAt`);
  });

  const evidences = array(document.evidences, "evidences");
  evidences.forEach((value, index) => {
    const item = record(value);
    string(item.evidenceId, `evidences[${index}].evidenceId`, 256);
    string(item.projectId, `evidences[${index}].projectId`, 256);
    optionalString(item.stageSpecId, `evidences[${index}].stageSpecId`, 256);
    optionalString(item.stepSpecId, `evidences[${index}].stepSpecId`, 256);
    optionalString(item.attemptId, `evidences[${index}].attemptId`, 256);
    string(item.type, `evidences[${index}].type`, 256);
    string(item.source, `evidences[${index}].source`, 256);
    string(item.producer, `evidences[${index}].producer`, 256);
    timestamp(item.timestamp, `evidences[${index}].timestamp`);
    if (item.exitCode !== null && (typeof item.exitCode !== "number" || !Number.isSafeInteger(item.exitCode))) throw new AutomationSchemaError("Evidence exitCode must be an integer or null.");
    optionalString(item.sha256, `evidences[${index}].sha256`, 128);
    optionalString(item.artifactRefId, `evidences[${index}].artifactRefId`, 256);
    metadata(item.metadata, `evidences[${index}].metadata`);
    if (item.correlation !== undefined && item.correlation !== null) {
      try {
        createEvidenceCorrelation(item.correlation as Record<string, unknown>);
      } catch (error) {
        throw new AutomationSchemaError(error instanceof Error ? `evidences[${index}].correlation: ${error.message}` : `evidences[${index}].correlation is invalid.`);
      }
    }
  });

  const artifacts = array(document.artifactRefs, "artifactRefs");
  artifacts.forEach((value, index) => {
    const item = record(value);
    string(item.artifactRefId, `artifactRefs[${index}].artifactRefId`, 256);
    string(item.projectId, `artifactRefs[${index}].projectId`, 256);
    string(item.kind, `artifactRefs[${index}].kind`, 256);
    string(item.pathOrUri, `artifactRefs[${index}].pathOrUri`, 2_048);
    string(item.sha256, `artifactRefs[${index}].sha256`, 128);
    if (item.size !== null && (typeof item.size !== "number" || !Number.isSafeInteger(item.size) || item.size < 0)) throw new AutomationSchemaError("Artifact size must be a non-negative integer or null.");
    timestamp(item.createdAt, `artifactRefs[${index}].createdAt`);
  });

  const claims = array(document.resourceClaims, "resourceClaims");
  claims.forEach((value, index) => {
    const item = record(value);
    string(item.resourceClaimId, `resourceClaims[${index}].resourceClaimId`, 256);
    string(item.projectId, `resourceClaims[${index}].projectId`, 256);
    enumValue(item.resourceType, `resourceClaims[${index}].resourceType`, RESOURCE_TYPES);
    string(item.resourceKey, `resourceClaims[${index}].resourceKey`, 512);
    enumValue(item.mode, `resourceClaims[${index}].mode`, RESOURCE_MODES);
    enumValue(item.state, `resourceClaims[${index}].state`, RESOURCE_STATES);
    timestamp(item.requestedAt, `resourceClaims[${index}].requestedAt`);
    optionalString(item.acquiredAt, `resourceClaims[${index}].acquiredAt`, 64);
    optionalString(item.releasedAt, `resourceClaims[${index}].releasedAt`, 64);
    optionalString(item.ownerAttemptId, `resourceClaims[${index}].ownerAttemptId`, 256);
    optionalString(item.resourceLeaseRef ?? null, `resourceClaims[${index}].resourceLeaseRef`, 256);
    if (item.leaseEpoch !== undefined && item.leaseEpoch !== null && (!Number.isSafeInteger(item.leaseEpoch) || (item.leaseEpoch as number) < 0)) throw new AutomationSchemaError(`resourceClaims[${index}].leaseEpoch must be a non-negative integer or null.`);
  });

  const snapshots = array(document.workspaceSnapshots, "workspaceSnapshots");
  snapshots.forEach((value, index) => {
    const item = record(value);
    string(item.workspaceSnapshotId, `workspaceSnapshots[${index}].workspaceSnapshotId`, 256);
    string(item.projectId, `workspaceSnapshots[${index}].projectId`, 256);
    string(item.canonicalPath, `workspaceSnapshots[${index}].canonicalPath`, 4_096);
    optionalString(item.branch, `workspaceSnapshots[${index}].branch`, 256);
    optionalString(item.baseCommit, `workspaceSnapshots[${index}].baseCommit`, 256);
    optionalString(item.workingTreeFingerprint, `workspaceSnapshots[${index}].workingTreeFingerprint`, 256);
    optionalString(item.worktreeId, `workspaceSnapshots[${index}].worktreeId`, 256);
    timestamp(item.createdAt, `workspaceSnapshots[${index}].createdAt`);
  });

  const policies = array(document.policyVersions, "policyVersions");
  const policyVersionsByProject = new Set<string>();
  policies.forEach((value, index) => {
    const item = record(value);
    string(item.policyVersionId, `policyVersions[${index}].policyVersionId`, 256);
    string(item.projectId, `policyVersions[${index}].projectId`, 256);
    integer(item.version, `policyVersions[${index}].version`, 1);
    const projectVersion = `${item.projectId}\u0000${item.version}`;
    if (policyVersionsByProject.has(projectVersion)) throw new AutomationSchemaError(`policyVersions[${index}] duplicates a project policy version.`);
    policyVersionsByProject.add(projectVersion);
    optionalString(item.preset, `policyVersions[${index}].preset`, 256);
    metadata(item.payload, `policyVersions[${index}].payload`);
    timestamp(item.createdAt, `policyVersions[${index}].createdAt`);
    optionalString(item.supersedes, `policyVersions[${index}].supersedes`, 256);
  });

  const changeRequests = array(document.requirementChangeRequests, "requirementChangeRequests");
  const changeStatuses = new Set(["DRAFT", "ANALYZING", "WAITING_USER_CONFIRMATION", "APPROVED", "REJECTED", "APPLIED", "CANCELLED"]);
  const replanLevels = new Set(["NONE", "STAGE", "WORKFLOW", "FOUNDATIONAL"]);
  changeRequests.forEach((value, index) => {
    const item = record(value);
    const field = `requirementChangeRequests[${index}]`;
    string(item.changeRequestId, `${field}.changeRequestId`, 256);
    string(item.projectId, `${field}.projectId`, 256);
    string(item.baseRequirementVersionId, `${field}.baseRequirementVersionId`, 256);
    string(item.requestedChange, `${field}.requestedChange`, 16_384);
    string(item.reason, `${field}.reason`, 16_384);
    enumValue(item.sourceActor, `${field}.sourceActor`, new Set(["SYSTEM", "USER", "NATIVE_RUNTIME", "WEBGPT_RUNTIME", "AUTOMATION", "TEST"]));
    enumValue(item.status, `${field}.status`, changeStatuses);
    string(item.basePayloadSha256, `${field}.basePayloadSha256`, 128);
    optionalString(item.candidateRequirementVersionId, `${field}.candidateRequirementVersionId`, 256);
    optionalString(item.candidatePayloadSha256, `${field}.candidatePayloadSha256`, 128);
    timestamp(item.createdAt, `${field}.createdAt`);
    timestamp(item.updatedAt, `${field}.updatedAt`);
    integer(item.revision, `${field}.revision`, 0);
    if (item.impactAnalysis !== null) {
      const impact = record(item.impactAnalysis);
      for (const key of ["changedRequirementSections", "acceptanceImpact", "riskImpact", "externalDependencyImpact", "affectedPlanRefs", "newBlockingQuestions", "newAssumptions"] as const) {
        const values = array(impact[key], `${field}.impactAnalysis.${key}`);
        values.forEach((entry, entryIndex) => string(entry, `${field}.impactAnalysis.${key}[${entryIndex}]`, 4_096));
      }
      enumValue(impact.replanLevel, `${field}.impactAnalysis.replanLevel`, replanLevels);
      if (typeof impact.requiresPlannerReplan !== "boolean") throw new AutomationSchemaError(`${field}.impactAnalysis.requiresPlannerReplan must be boolean.`);
      string(impact.analysisSha256, `${field}.impactAnalysis.analysisSha256`, 128);
    }
  });
}

function tableById(document: Record<string, unknown>, table: string, key: string): Map<string, Record<string, unknown>> {
  return new Map(array(document[table], table).map((value, index) => {
    const item = record(value);
    return [string(item[key], `${table}[${index}].${key}`, 256), item];
  }));
}

function validateReferences(document: Record<string, unknown>): void {
  const projects = tableById(document, "automationProjects", "projectId");
  const origins = tableById(document, "requirementOrigins", "requirementOriginId");
  const requirements = tableById(document, "requirementVersions", "requirementVersionId");
  const changeRequests = tableById(document, "requirementChangeRequests", "changeRequestId");
  const plans = tableById(document, "planVersions", "planVersionId");
  const stages = tableById(document, "stageSpecs", "stageSpecId");
  const steps = tableById(document, "stepSpecs", "stepSpecId");
  const runtimes = tableById(document, "stepRuntimes", "stepRuntimeId");
  const attempts = tableById(document, "executionAttempts", "attemptId");
  const intents = tableById(document, "actionIntents", "intentId");
  const actionAttempts = tableById(document, "actionAttempts", "actionAttemptId");
  const receipts = tableById(document, "actionReceipts", "receiptId");
  const claims = tableById(document, "resourceClaims", "resourceClaimId");
  const externals = tableById(document, "externalRefs", "externalRefId");
  const evidences = tableById(document, "evidences", "evidenceId");
  const artifacts = tableById(document, "artifactRefs", "artifactRefId");
  const snapshots = tableById(document, "workspaceSnapshots", "workspaceSnapshotId");
  const policies = tableById(document, "policyVersions", "policyVersionId");

  const providerRequestOwners = new Map<string, string>();
  const providerObservationOwners = new Map<string, string>();
  for (const item of actionAttempts.values()) {
    const owningIntent = intents.get(item.intentId as string);
    if (!owningIntent) continue;
    for (const [field, expectedKind, owners] of [
      ["providerRequestRef", "WEBGPT_PROVIDER_REQUEST", providerRequestOwners],
      ["providerObservationRef", "WEBGPT_PROVIDER_OBSERVATION", providerObservationOwners],
    ] as const) {
      const reference = item[field];
      if (reference === null || reference === undefined) continue;
      const ref = externals.get(reference as string);
      if (!ref) throw new AutomationSchemaError(`actionAttempts.${field} references a missing ExternalRef.`);
      if (ref.kind !== expectedKind || ref.projectId !== owningIntent.projectId) throw new AutomationSchemaError(`actionAttempts.${field} crosses a provider kind or project boundary.`);
      const owner = owners.get(reference as string);
      if (owner && owner !== item.actionAttemptId) throw new AutomationSchemaError(`A provider ExternalRef cannot be attached to multiple ActionAttempts.`);
      owners.set(reference as string, item.actionAttemptId as string);
    }
  }

  const requireSameProject = (table: Map<string, Record<string, unknown>>, idValue: unknown, projectId: string, field: string): Record<string, unknown> | null => {
    if (idValue === null) return null;
    const idText = string(idValue, field, 256);
    const item = table.get(idText);
    if (!item) throw new AutomationSchemaError(`${field} references a missing entity.`);
    if (item.projectId !== projectId) throw new AutomationSchemaError(`${field} references another project.`);
    return item;
  };
  const requireSameAttemptProject = (idValue: unknown, projectId: string, field: string): Record<string, unknown> | null => {
    if (idValue === null) return null;
    const idText = string(idValue, field, 256);
    const executionAttempt = attempts.get(idText);
    if (executionAttempt) {
      if (executionAttempt.projectId !== projectId) throw new AutomationSchemaError(`${field} references another project.`);
      return executionAttempt;
    }
    const actionAttempt = actionAttempts.get(idText);
    if (actionAttempt) {
      const intent = intents.get(actionAttempt.intentId as string);
      if (!intent) throw new AutomationSchemaError(`${field} references an action attempt with a missing intent.`);
      if (intent.projectId !== projectId) throw new AutomationSchemaError(`${field} references another project.`);
      return actionAttempt;
    }
    throw new AutomationSchemaError(`${field} references a missing entity.`);
  };
  const requireSameEvidenceProject = (idValue: unknown, projectId: string, field: string): Record<string, unknown> | null => {
    if (idValue === null) return null;
    const idText = string(idValue, field, 256);
    const evidence = evidences.get(idText);
    if (!evidence) throw new AutomationSchemaError(`${field} references a missing entity.`);
    if (evidence.projectId !== projectId) throw new AutomationSchemaError(`${field} references another project.`);
    return evidence;
  };
  const projectForStage = (stageId: unknown, field: string): string | null => {
    if (stageId === null) return null;
    const stage = stages.get(string(stageId, field, 256));
    if (!stage) throw new AutomationSchemaError(`${field} references a missing stage.`);
    const plan = plans.get(stage.planVersionId as string);
    if (!plan) throw new AutomationSchemaError(`${field} references a stage with a missing plan.`);
    return plan.projectId as string;
  };
  const projectForStep = (stepId: unknown, field: string): string | null => {
    if (stepId === null) return null;
    const step = steps.get(string(stepId, field, 256));
    if (!step) throw new AutomationSchemaError(`${field} references a missing step.`);
    return projectForStage(step.stageSpecId, `${field}.stageSpecId`);
  };
  const projectForReceipt = (receiptId: unknown, field: string): string | null => {
    if (receiptId === null) return null;
    const receipt = receipts.get(string(receiptId, field, 256));
    if (!receipt) throw new AutomationSchemaError(`${field} references a missing receipt.`);
    const actionAttempt = actionAttempts.get(receipt.actionAttemptId as string);
    if (!actionAttempt) throw new AutomationSchemaError(`${field} references a receipt with a missing action attempt.`);
    const intent = intents.get(actionAttempt.intentId as string);
    if (!intent) throw new AutomationSchemaError(`${field} references a receipt with a missing intent.`);
    return intent.projectId as string;
  };

  for (const project of projects.values()) {
    const projectId = project.projectId as string;
    const requirement = requireSameProject(requirements, project.activeRequirementVersionId, projectId, `${projectId}.activeRequirementVersionId`);
    const plan = requireSameProject(plans, project.activePlanVersionId, projectId, `${projectId}.activePlanVersionId`);
    requireSameProject(policies, project.policyVersionId, projectId, `${projectId}.policyVersionId`);
    if (requirement && requirement.status === "SUPERSEDED") throw new AutomationSchemaError(`${projectId}.activeRequirementVersionId cannot point to a superseded version.`);
    if (requirement && requirement.status !== "CONFIRMED" && requirement.status !== "ACTIVE") throw new AutomationSchemaError(`${projectId}.activeRequirementVersionId must point to a confirmed or active version.`);
    if (plan && plan.status !== "ACTIVE") throw new AutomationSchemaError(`${projectId}.activePlanVersionId must point to an active PlanVersion.`);
    if (plan) {
      const boundRequirement = requirements.get(plan.requirementVersionId as string);
      if (!boundRequirement) throw new AutomationSchemaError(`${projectId}.activePlanVersionId references a plan with a missing RequirementVersion.`);
      if (boundRequirement.projectId !== projectId) throw new AutomationSchemaError(`${projectId}.activePlanVersionId references a plan bound to another project.`);
      if (project.activeRequirementVersionId !== boundRequirement.requirementVersionId) throw new AutomationSchemaError(`${projectId}.activePlanVersionId must bind the current active RequirementVersion.`);
      if (boundRequirement.status !== "ACTIVE" && boundRequirement.status !== "CONFIRMED") throw new AutomationSchemaError(`${projectId}.activePlanVersionId must bind an active or confirmed RequirementVersion.`);
      if (plan.requirementPayloadSha256 !== undefined && plan.requirementPayloadSha256 !== null && plan.requirementPayloadSha256 !== boundRequirement.payloadSha256) throw new AutomationSchemaError(`${projectId}.activePlanVersionId plan requirement hash does not match its RequirementVersion.`);
    }
  }
  for (const item of policies.values()) {
    const superseded = requireSameProject(policies, item.supersedes, item.projectId as string, "policyVersions.supersedes");
    if (Number(item.version) === 1 && superseded !== null) throw new AutomationSchemaError("Policy version 1 cannot supersede a predecessor.");
    if (Number(item.version) > 1 && superseded === null) throw new AutomationSchemaError("Policy versions after version 1 require an explicit predecessor.");
    if (superseded && Number(superseded.version) !== Number(item.version) - 1) throw new AutomationSchemaError("PolicyVersion predecessor must be the immediately previous version in the same project.");
  }
  const referencedOrigins = new Set<string>();
  for (const item of requirements.values()) {
    requireSameProject(projects, item.projectId, item.projectId as string, "requirementVersions.projectId");
    requireSameProject(origins, item.originRef, item.projectId as string, "requirementVersions.originRef");
    referencedOrigins.add(item.originRef as string);
    requireSameProject(requirements, item.supersedes, item.projectId as string, "requirementVersions.supersedes");
    const predecessor = item.supersedes === null ? null : requirements.get(item.supersedes as string);
    if (Number(item.version) === 1 && predecessor !== null) throw new AutomationSchemaError("Requirement version 1 cannot supersede a predecessor.");
    if (Number(item.version) > 1 && predecessor === null) throw new AutomationSchemaError("Requirement versions after version 1 require an explicit predecessor.");
    if (predecessor && Number(predecessor.version) !== Number(item.version) - 1) throw new AutomationSchemaError("RequirementVersion predecessor must be the immediately previous version.");
  }
  for (const origin of origins.values()) {
    if (!projects.has(origin.projectId as string)) throw new AutomationSchemaError("requirementOrigins.projectId references a missing project.");
    if (!referencedOrigins.has(origin.requirementOriginId as string)) throw new AutomationSchemaError("requirementOrigins contains an orphan origin.");
  }
  for (const item of changeRequests.values()) {
    const projectId = item.projectId as string;
    if (!projects.has(projectId)) throw new AutomationSchemaError("requirementChangeRequests.projectId references a missing project.");
    const base = requireSameProject(requirements, item.baseRequirementVersionId, projectId, "requirementChangeRequests.baseRequirementVersionId");
    if (base && base.payloadSha256 !== item.basePayloadSha256) throw new AutomationSchemaError("requirementChangeRequests.basePayloadSha256 does not match its base version.");
    requireSameProject(requirements, item.candidateRequirementVersionId, projectId, "requirementChangeRequests.candidateRequirementVersionId");
  }
  for (const item of plans.values()) {
    requireSameProject(projects, item.projectId, item.projectId as string, "planVersions.projectId");
    const requirement = requireSameProject(requirements, item.requirementVersionId, item.projectId as string, "planVersions.requirementVersionId");
    if (requirement?.status === "SUPERSEDED") throw new AutomationSchemaError("A plan cannot bind a superseded requirement version.");
    if (item.requirementPayloadSha256 !== undefined && item.requirementPayloadSha256 !== null && item.requirementPayloadSha256 !== requirement?.payloadSha256) throw new AutomationSchemaError("PlanVersion requirementPayloadSha256 does not match its RequirementVersion.");
    const superseded = requireSameProject(plans, item.supersedes, item.projectId as string, "planVersions.supersedes");
    if (Number(item.version) === 1 && superseded !== null) throw new AutomationSchemaError("Plan version 1 cannot supersede a predecessor.");
    if (Number(item.version) > 1 && superseded === null) throw new AutomationSchemaError("Plan versions after version 1 require an explicit predecessor.");
    if (superseded && Number(superseded.version) !== Number(item.version) - 1) throw new AutomationSchemaError("PlanVersion predecessor must be the immediately previous version in the same project.");
    if (item.currentStageId !== undefined && item.currentStageId !== null) {
      const currentStage = stages.get(string(item.currentStageId, "planVersions.currentStageId", 256));
      if (!currentStage) throw new AutomationSchemaError("planVersions.currentStageId references a missing StageSpec.");
      if (currentStage.planVersionId !== item.planVersionId) throw new AutomationSchemaError("planVersions.currentStageId must belong to the same PlanVersion.");
    }
  }
  const stagesForVersion = new Set<string>();
  for (const item of stages.values()) {
    const plan = plans.get(item.planVersionId as string);
    if (!plan) throw new AutomationSchemaError("stageSpecs.planVersionId references a missing plan.");
    const stageKey = `${item.planVersionId}:${item.stageKey}:${item.specVersion}`;
    if (stagesForVersion.has(stageKey)) throw new AutomationSchemaError("Duplicate StageSpec key/version in a PlanVersion.");
    stagesForVersion.add(stageKey);
    const predecessor = item.supersedes === null || item.supersedes === undefined
      ? null
      : stages.get(string(item.supersedes, "stageSpecs.supersedes", 256)) ?? null;
    if (item.supersedes !== null && item.supersedes !== undefined && predecessor === null) throw new AutomationSchemaError("stageSpecs.supersedes references a missing StageSpec.");
    if (predecessor && predecessor.planVersionId !== item.planVersionId) throw new AutomationSchemaError("stageSpecs.supersedes must remain within the same PlanVersion.");
    if (Number(item.specVersion) === 1 && predecessor !== null) throw new AutomationSchemaError("StageSpec version 1 cannot supersede a predecessor.");
    if (Number(item.specVersion) > 1 && predecessor === null) throw new AutomationSchemaError("StageSpec versions after version 1 require an explicit predecessor.");
    if (predecessor && Number(predecessor.specVersion) !== Number(item.specVersion) - 1) throw new AutomationSchemaError("StageSpec predecessor must be the immediately previous version.");
  }
  const stepsForVersion = new Set<string>();
  for (const item of steps.values()) {
    const stage = stages.get(item.stageSpecId as string);
    if (!stage) throw new AutomationSchemaError("stepSpecs.stageSpecId references a missing stage.");
    const stepKey = `${item.stageSpecId}:${item.stepKey}:${item.specVersion}`;
    if (stepsForVersion.has(stepKey)) throw new AutomationSchemaError("Duplicate StepSpec key/version in a StageSpec.");
    stepsForVersion.add(stepKey);
    const predecessor = item.supersedes === null || item.supersedes === undefined
      ? null
      : steps.get(string(item.supersedes, "stepSpecs.supersedes", 256)) ?? null;
    if (item.supersedes !== null && item.supersedes !== undefined && predecessor === null) throw new AutomationSchemaError("stepSpecs.supersedes references a missing StepSpec.");
    if (predecessor && predecessor.stageSpecId !== item.stageSpecId) throw new AutomationSchemaError("stepSpecs.supersedes must remain within the same StageSpec.");
    if (Number(item.specVersion) === 1 && predecessor !== null) throw new AutomationSchemaError("StepSpec version 1 cannot supersede a predecessor.");
    if (Number(item.specVersion) > 1 && predecessor === null) throw new AutomationSchemaError("StepSpec versions after version 1 require an explicit predecessor.");
    if (predecessor && Number(predecessor.specVersion) !== Number(item.specVersion) - 1) throw new AutomationSchemaError("StepSpec predecessor must be the immediately previous version.");
  }
  for (const item of runtimes.values()) {
    const step = steps.get(item.stepSpecId as string);
    if (!step) throw new AutomationSchemaError("stepRuntimes.stepSpecId references a missing StepSpec.");
    const attempt = requireSameProject(attempts, item.currentAttemptId, projectForStep(item.stepSpecId, "stepRuntimes.stepSpecId") as string, "stepRuntimes.currentAttemptId");
    if (attempt && attempt.stepSpecId !== step.stepSpecId) throw new AutomationSchemaError("stepRuntimes.currentAttemptId does not belong to its StepSpec.");
  }
  for (const item of attempts.values()) {
    const project = projects.get(item.projectId as string);
    const stage = stages.get(item.stageSpecId as string);
    const step = steps.get(item.stepSpecId as string);
    if (!project || !stage || !step) throw new AutomationSchemaError("executionAttempts contains a missing parent reference.");
    const plan = plans.get(stage.planVersionId as string);
    if (!plan || plan.projectId !== project.projectId || step.stageSpecId !== stage.stageSpecId) throw new AutomationSchemaError("executionAttempts crosses a project or StepSpec boundary.");
    const runtime = [...runtimes.values()].find((candidate) => candidate.stepSpecId === step.stepSpecId);
    if (!runtime) throw new AutomationSchemaError("executionAttempts.stepSpecId has no StepRuntime.");
    if (runtime.currentAttemptId !== null && !attempts.has(runtime.currentAttemptId as string)) throw new AutomationSchemaError("stepRuntimes.currentAttemptId references a missing attempt.");
  }
  const logicalPlannerOwners = new Map<string, string>();
  for (const item of intents.values()) {
    if (!projects.has(item.projectId as string)) throw new AutomationSchemaError("actionIntents.projectId references a missing project.");
    const projectId = item.projectId as string;
    if (projectForStage(item.stageSpecId, "actionIntents.stageSpecId") !== null && projectForStage(item.stageSpecId, "actionIntents.stageSpecId") !== projectId) throw new AutomationSchemaError("actionIntents.stageSpecId crosses a project boundary.");
    if (projectForStep(item.stepSpecId, "actionIntents.stepSpecId") !== null && projectForStep(item.stepSpecId, "actionIntents.stepSpecId") !== projectId) throw new AutomationSchemaError("actionIntents.stepSpecId crosses a project boundary.");
    requireSameProject(attempts, item.attemptId, projectId, "actionIntents.attemptId");
    requireSameProject(policies, item.policyVersionId ?? null, projectId, "actionIntents.policyVersionId");
    if (item.actionType === "PLANNER_REQUEST") {
      const logicalId = (item.logicalPlannerRequestId ?? item.intentId) as string;
      const owner = logicalPlannerOwners.get(`${projectId}\u0000${logicalId}`);
      if (owner && owner !== item.intentId) throw new AutomationSchemaError("A logical PlannerRequest cannot be represented by multiple ActionIntents.");
      logicalPlannerOwners.set(`${projectId}\u0000${logicalId}`, item.intentId as string);
      if (item.plannerState === "PROMOTED" && (item.promotedPlanVersionId === null || item.promotedPlanVersionId === undefined)) throw new AutomationSchemaError("A promoted logical PlannerRequest requires promotedPlanVersionId.");
      if (item.promotedPlanVersionId !== null && item.promotedPlanVersionId !== undefined) {
        requireSameProject(plans, item.promotedPlanVersionId, projectId, "actionIntents.promotedPlanVersionId");
        if (item.plannerState !== "PROMOTED") throw new AutomationSchemaError("promotedPlanVersionId requires plannerState PROMOTED.");
      }
    }
  }
  for (const item of actionAttempts.values()) {
    const intent = intents.get(item.intentId as string);
    if (!intent) throw new AutomationSchemaError("actionAttempts.intentId references a missing intent.");
    requireSameProject(policies, item.policyVersionId ?? null, intent.projectId as string, "actionAttempts.policyVersionId");
    try {
      assertIntentAttemptPolicyPin(intent, item);
    } catch (error) {
      if (error instanceof Error) throw new AutomationSchemaError(error.message);
      throw error;
    }
    if (intent.actionType === "PLANNER_REQUEST") {
      const logicalId = (intent.logicalPlannerRequestId ?? intent.intentId) as string;
      if (item.createdAt === undefined || item.createdAt === null) throw new AutomationSchemaError("Planner actionAttempts.createdAt is required.");
      if (item.logicalPlannerRequestId !== logicalId) throw new AutomationSchemaError("actionAttempts.logicalPlannerRequestId must match its owning Planner ActionIntent.");
      if (item.attemptNumber === undefined || item.attemptNumber === null) throw new AutomationSchemaError("Planner actionAttempts.attemptNumber is required.");
      if (item.providerTargetRef !== intent.targetRef) throw new AutomationSchemaError("actionAttempts.providerTargetRef must match its owning Planner target.");
    } else if ((item.logicalPlannerRequestId !== undefined && item.logicalPlannerRequestId !== null) || (item.attemptNumber !== undefined && item.attemptNumber !== null) || (item.providerTargetRef !== undefined && item.providerTargetRef !== null) || (item.externalSideEffectCertainty !== undefined && item.externalSideEffectCertainty !== null) || (item.plannerResultClassification !== undefined && item.plannerResultClassification !== null)) {
      throw new AutomationSchemaError("Planner attempt fields are only allowed for Planner ActionAttempts.");
    }
  }
  for (const intent of intents.values()) {
    if (intent.actionType !== "PLANNER_REQUEST") continue;
    const plannerAttempts = [...actionAttempts.values()]
      .filter((attempt) => attempt.intentId === intent.intentId)
      .sort((left, right) => (left.attemptNumber as number) - (right.attemptNumber as number));
    if (plannerAttempts.length > 2) throw new AutomationSchemaError("A logical PlannerRequest cannot exceed maxProviderAttempts=2.");
    plannerAttempts.forEach((attempt, index) => {
      if (attempt.attemptNumber !== index + 1) throw new AutomationSchemaError("Planner ProviderAttempt numbers must be contiguous and start at 1.");
    });
  }
  for (const item of receipts.values()) {
    const attempt = actionAttempts.get(item.actionAttemptId as string);
    if (!attempt) throw new AutomationSchemaError("actionReceipts.actionAttemptId references a missing attempt.");
    const intent = intents.get(attempt.intentId as string);
    if (!intent) throw new AutomationSchemaError("actionReceipts.actionAttemptId references an attempt with a missing intent.");
    for (const ref of item.externalRefs as string[]) requireSameProject(externals, ref, intent.projectId as string, "actionReceipts.externalRefs");
    if (item.providerRequestRef !== null && item.providerRequestRef !== undefined && item.providerRequestRef !== attempt.providerRequestRef) throw new AutomationSchemaError("actionReceipts.providerRequestRef must match its ActionAttempt correlation.");
    if (item.providerObservationRef !== null && item.providerObservationRef !== undefined && item.providerObservationRef !== attempt.providerObservationRef) throw new AutomationSchemaError("actionReceipts.providerObservationRef must match its ActionAttempt correlation.");
    for (const ref of (item.evidenceRefs ?? []) as string[]) requireSameEvidenceProject(ref, intent.projectId as string, "actionReceipts.evidenceRefs");
  }
  for (const item of claims.values()) {
    if (!projects.has(item.projectId as string)) throw new AutomationSchemaError("resourceClaims.projectId references a missing project.");
    if (item.ownerAttemptId !== null) requireSameAttemptProject(item.ownerAttemptId, item.projectId as string, "resourceClaims.ownerAttemptId");
    if (item.state === "ACQUIRED" && (item.ownerAttemptId === null || item.acquiredAt === null)) throw new AutomationSchemaError("An acquired resource claim requires an owner attempt and acquiredAt.");
    if (item.state === "RELEASED" && item.releasedAt === null) throw new AutomationSchemaError("A released resource claim requires releasedAt.");
  }
  for (const item of externals.values()) if (!projects.has(item.projectId as string)) throw new AutomationSchemaError("externalRefs.projectId references a missing project.");
  for (const item of evidences.values()) {
    if (!projects.has(item.projectId as string)) throw new AutomationSchemaError("evidences.projectId references a missing project.");
    requireSameProject(artifacts, item.artifactRefId, item.projectId as string, "evidences.artifactRefId");
    requireSameAttemptProject(item.attemptId, item.projectId as string, "evidences.attemptId");
    const correlation = item.correlation as { workflowActionId?: string | null; artifactRefs?: string[]; evidenceRefs?: string[] } | null | undefined;
    if (correlation) {
      requireSameProject(intents, correlation.workflowActionId ?? null, item.projectId as string, "evidences.correlation.workflowActionId");
      for (const ref of correlation.artifactRefs ?? []) requireSameProject(artifacts, ref, item.projectId as string, "evidences.correlation.artifactRefs");
      for (const ref of correlation.evidenceRefs ?? []) requireSameEvidenceProject(ref, item.projectId as string, "evidences.correlation.evidenceRefs");
    }
  }
  for (const item of artifacts.values()) if (!projects.has(item.projectId as string)) throw new AutomationSchemaError("artifactRefs.projectId references a missing project.");
  for (const item of snapshots.values()) if (!projects.has(item.projectId as string)) throw new AutomationSchemaError("workspaceSnapshots.projectId references a missing project.");
  for (const value of array(document.checkpoints, "checkpoints")) {
    const item = record(value);
    const projectId = item.projectId as string;
    if (!projects.has(projectId)) throw new AutomationSchemaError("checkpoints.projectId references a missing project.");
    for (const ref of [item.requirementVersionId, item.planVersionId]) requireSameProject(ref === item.requirementVersionId ? requirements : plans, ref, projectId, "checkpoint.versionRef");
    if (projectForStage(item.currentStageSpecId, "checkpoints.currentStageSpecId") !== null && projectForStage(item.currentStageSpecId, "checkpoints.currentStageSpecId") !== projectId) throw new AutomationSchemaError("checkpoints.currentStageSpecId crosses a project boundary.");
    if (projectForStep(item.currentStepSpecId, "checkpoints.currentStepSpecId") !== null && projectForStep(item.currentStepSpecId, "checkpoints.currentStepSpecId") !== projectId) throw new AutomationSchemaError("checkpoints.currentStepSpecId crosses a project boundary.");
    if (item.currentStepRuntimeId !== null) {
      const runtime = runtimes.get(string(item.currentStepRuntimeId, "checkpoints.currentStepRuntimeId", 256));
      if (!runtime) throw new AutomationSchemaError("checkpoints.currentStepRuntimeId references a missing runtime.");
      if (item.currentStepSpecId !== runtime.stepSpecId) throw new AutomationSchemaError("checkpoints.currentStepRuntimeId does not match currentStepSpecId.");
      if (projectForStep(runtime.stepSpecId, "checkpoints.currentStepRuntimeId.stepSpecId") !== projectId) throw new AutomationSchemaError("checkpoints.currentStepRuntimeId crosses a project boundary.");
    }
    requireSameProject(attempts, item.currentAttemptId, projectId, "checkpoints.currentAttemptId");
    requireSameProject(intents, item.lastActionIntentId, projectId, "checkpoints.lastActionIntentId");
    requireSameProject(policies, item.policyVersionId ?? null, projectId, "checkpoints.policyVersionId");
    if (projectForReceipt(item.lastActionReceiptId, "checkpoints.lastActionReceiptId") !== null && projectForReceipt(item.lastActionReceiptId, "checkpoints.lastActionReceiptId") !== projectId) throw new AutomationSchemaError("checkpoints.lastActionReceiptId crosses a project boundary.");
    requireSameProject(snapshots, item.workspaceSnapshotRef, projectId, "checkpoints.workspaceSnapshotRef");
    for (const ref of item.resourceClaimRefs as string[]) requireSameProject(claims, ref, projectId, "checkpoints.resourceClaimRefs");
    for (const ref of item.externalRefs as string[]) requireSameProject(externals, ref, projectId, "checkpoints.externalRefs");
    for (const ref of item.evidenceRefs as string[]) requireSameProject(evidences, ref, projectId, "checkpoints.evidenceRefs");
  }
}

export function createEmptyAutomationDocument(): AutomationDocument {
  return {
    automationSchemaVersion: AUTOMATION_SCHEMA_VERSION,
    automationProjects: [],
    requirementOrigins: [],
    requirementVersions: [],
    requirementAlignmentSessions: [],
    requirementAlignmentRounds: [],
    requirementQuestions: [],
    requirementAssumptions: [],
    requirementChangeRequests: [],
    planVersions: [],
    stageSpecs: [],
    stepSpecs: [],
    stepRuntimes: [],
    executionAttempts: [],
    actionIntents: [],
    actionAttempts: [],
    actionReceipts: [],
    auditEvents: [],
    checkpoints: [],
    externalRefs: [],
    evidences: [],
    artifactRefs: [],
    resourceClaims: [],
    workspaceSnapshots: [],
    policyVersions: [],
  };
}

export function validateAutomationDocument(value: unknown): AutomationDocument {
  const document = record(value);
  if (document.automationSchemaVersion !== AUTOMATION_SCHEMA_VERSION) {
    throw new AutomationSchemaError("Automation schema version is unsupported.", "AUTOMATION_SCHEMA_VERSION_UNSUPPORTED");
  }
  const projects = array(document.automationProjects, "automationProjects");
  validateUniqueIds(projects, "projectId", "automationProjects");
  projects.forEach((item, index) => validateProject(record(item), index));
  validateUniqueIds(array(document.requirementChangeRequests, "requirementChangeRequests"), "changeRequestId", "requirementChangeRequests");
  validateVersions(document);
  try {
    validateRequirementDomain(document);
  } catch (error) {
    if (error instanceof RequirementDomainError) throw new AutomationSchemaError(error.message);
    throw error;
  }
  validateCommonTables(document);
  validateReferences(document);
  return document as unknown as AutomationDocument;
}

type LegacyProject = { projectId?: unknown; name?: unknown; createdAt?: unknown; updatedAt?: unknown };

function migratedTimestamp(value: unknown): string {
  return typeof value === "string" && Number.isFinite(Date.parse(value)) ? value : new Date(0).toISOString();
}

function migrateV0ToV3(value: Record<string, unknown>): AutomationDocument {
  const legacyProjects = Array.isArray(value.projects) ? value.projects as LegacyProject[] : [];
  const document = createEmptyAutomationDocument();
  document.automationProjects = legacyProjects.map((project, index) => {
    const projectId = typeof project.projectId === "string" && project.projectId ? project.projectId : `legacy-project-${index + 1}`;
    const createdAt = migratedTimestamp(project.createdAt);
    const updatedAt = migratedTimestamp(project.updatedAt ?? createdAt);
    return {
      projectId,
      name: typeof project.name === "string" && project.name ? project.name : projectId,
      lifecycle: "DRAFT",
      createdAt,
      updatedAt,
      activeRequirementVersionId: null,
      activePlanVersionId: null,
      policyVersionId: null,
      revision: 0,
    };
  });
  (document as unknown as Record<string, unknown>).automationSchemaVersion = 3;
  return document;
}

function legacyRequirementPayload(item: Record<string, unknown>): { canonicalPayload: string; payloadSha256: string } {
  const canonicalPayload = canonicalizeJson(JSON.stringify({
    legacyContentRef: item.contentRef ?? null,
    legacyStructuredPayloadRef: item.structuredPayloadRef ?? null,
  }), "legacyRequirement.canonicalPayload");
  return { canonicalPayload, payloadSha256: sha256Hex(canonicalPayload) };
}

function normalizeLegacyAudit(value: unknown, index: number, previousHash: string | null): Record<string, unknown> {
  const item = record(value);
  const event = {
    eventId: typeof item.eventId === "string" && item.eventId ? item.eventId : `legacy-audit-${index + 1}`,
    projectId: typeof item.projectId === "string" && item.projectId ? item.projectId : "legacy-project-unknown",
    entityType: typeof item.entityType === "string" && item.entityType ? item.entityType : "Legacy",
    entityId: typeof item.entityId === "string" && item.entityId ? item.entityId : `legacy-${index + 1}`,
    eventType: typeof item.eventType === "string" && item.eventType ? item.eventType : "LEGACY_EVENT",
    eventVersion: Number.isSafeInteger(item.eventVersion) && (item.eventVersion as number) > 0 ? item.eventVersion : 1,
    sequence: index + 1,
    aggregateRevision: Number.isSafeInteger(item.aggregateRevision) && (item.aggregateRevision as number) >= 0 ? item.aggregateRevision : null,
    fromState: typeof item.fromState === "string" ? item.fromState : null,
    toState: typeof item.toState === "string" ? item.toState : null,
    prevHash: previousHash,
    timestamp: migratedTimestamp(item.timestamp),
    actorType: ["SYSTEM", "USER", "NATIVE_RUNTIME", "WEBGPT_RUNTIME", "AUTOMATION", "TEST"].includes(item.actorType as string) ? item.actorType : "SYSTEM",
    actorRef: typeof item.actorRef === "string" ? item.actorRef : null,
    boundedPayload: item.boundedPayload && typeof item.boundedPayload === "object" && !Array.isArray(item.boundedPayload) ? item.boundedPayload : {},
    correlationId: typeof item.correlationId === "string" ? item.correlationId : null,
    causationId: typeof item.causationId === "string" ? item.causationId : null,
  };
  const hash = createHash("sha256").update(JSON.stringify(event)).digest("hex");
  return { ...event, hash };
}

function migrateV1ToV3(value: Record<string, unknown>): AutomationDocument {
  const source = structuredClone(value) as Record<string, unknown>;
  const document = createEmptyAutomationDocument() as unknown as Record<string, unknown>;
  for (const table of ["automationProjects", "planVersions", "stageSpecs", "executionAttempts", "actionAttempts", "actionReceipts", "externalRefs", "evidences", "artifactRefs", "resourceClaims", "workspaceSnapshots", "policyVersions"] as const) {
    document[table] = Array.isArray(source[table]) ? source[table] : [];
  }
  const requirements = Array.isArray(source.requirementVersions) ? source.requirementVersions : [];
  document.requirementVersions = requirements.map((value) => {
    const item = record(value);
    const payload = typeof item.canonicalPayload === "string" && typeof item.payloadSha256 === "string"
      ? { canonicalPayload: item.canonicalPayload, payloadSha256: item.payloadSha256 }
      : legacyRequirementPayload(item);
    return { ...item, contentRef: item.contentRef ?? null, structuredPayloadRef: item.structuredPayloadRef ?? null, ...payload };
  });
  const attempts = Array.isArray(source.executionAttempts) ? source.executionAttempts : [];
  const steps = Array.isArray(source.stepSpecs) ? source.stepSpecs : [];
  document.stepSpecs = steps.map((value) => {
    const item = record(value);
    return { ...item, specStatus: item.specStatus ?? (item.status === "SUPERSEDED" ? "SUPERSEDED" : "ACTIVE") };
  }).map((item) => {
    const clone = { ...item } as Record<string, unknown>;
    delete clone.status;
    delete clone.terminalResult;
    return clone;
  });
  const suppliedRuntimes = Array.isArray(source.stepRuntimes) ? source.stepRuntimes : [];
  const runtimeByStep = new Map<string, Record<string, unknown>>();
  for (const value of suppliedRuntimes) {
    const item = record(value);
    runtimeByStep.set(String(item.stepSpecId), item);
  }
  document.stepRuntimes = (document.stepSpecs as Record<string, unknown>[]).map((step) => {
    const old = steps.map(record).find((candidate) => candidate.stepSpecId === step.stepSpecId);
    const supplied = runtimeByStep.get(String(step.stepSpecId));
    const oldStatus = old?.status;
    const lifecycle = supplied?.lifecycle ?? (["NOT_STARTED", "READY", "RUNNING", "VERIFYING", "REVIEWING", "TERMINAL"].includes(oldStatus as string) ? oldStatus : oldStatus === "SUPERSEDED" ? "TERMINAL" : "NOT_STARTED");
    const currentAttemptId = supplied?.currentAttemptId ?? (attempts.map(record).filter((candidate) => candidate.stepSpecId === step.stepSpecId).at(-1)?.attemptId ?? null);
    const timestamp = migratedTimestamp(supplied?.createdAt ?? step.createdAt);
    return { stepRuntimeId: supplied?.stepRuntimeId ?? `runtime:${String(step.stepSpecId)}`, stepSpecId: step.stepSpecId, lifecycle, terminalResult: supplied?.terminalResult ?? (oldStatus === "SUPERSEDED" ? "SUPERSEDED" : old?.terminalResult ?? null), waitReason: supplied?.waitReason ?? "NONE", currentAttemptId, revision: supplied?.revision ?? 0, createdAt: timestamp, updatedAt: migratedTimestamp(supplied?.updatedAt ?? timestamp) };
  });
  document.actionIntents = (Array.isArray(source.actionIntents) ? source.actionIntents : []).map((value) => {
    const item = record(value);
    const actionType = String(item.actionType);
    const targetRef = (item.targetRef ?? null) as string | null;
    const sideEffectClass = String(item.sideEffectClass);
    const payloadRef = (item.payloadRef ?? null) as string | null;
    const payloadHash = (item.payloadHash ?? null) as string | null;
    const expectedOutcomeRef = (item.expectedOutcomeRef ?? null) as string | null;
    const executionOptions = item.executionOptions && typeof item.executionOptions === "object" && !Array.isArray(item.executionOptions) ? item.executionOptions : {};
    return { ...item, payloadRef, payloadHash, executionOptions, expectedOutcomeRef, semanticSha256: computeActionSemanticSha256({ actionType, targetRef, sideEffectClass, payloadRef, payloadHash, executionOptions: executionOptions as Record<string, unknown>, expectedOutcomeRef }) };
  });
  const runtimeByStepId = new Map((document.stepRuntimes as Record<string, unknown>[]).map((runtime) => [String(runtime.stepSpecId), String(runtime.stepRuntimeId)]));
  document.checkpoints = (Array.isArray(source.checkpoints) ? source.checkpoints : []).map((value) => {
    const item = record(value);
    return { ...item, currentStepRuntimeId: item.currentStepRuntimeId ?? (item.currentStepSpecId ? runtimeByStepId.get(String(item.currentStepSpecId)) ?? null : null) };
  });
  const legacyAudit = Array.isArray(source.auditEvents) ? source.auditEvents : [];
  let previousHash: string | null = null;
  document.auditEvents = legacyAudit.map((value, index) => {
    const event = normalizeLegacyAudit(value, index, previousHash);
    previousHash = event.hash as string;
    return event;
  });
  (document as unknown as Record<string, unknown>).automationSchemaVersion = 3;
  return document as unknown as AutomationDocument;
}

function migrateV2ToV3(value: Record<string, unknown>): AutomationDocument {
  const document = structuredClone(value) as Record<string, unknown>;
  document.automationSchemaVersion = 3;
  for (const table of [
    "requirementAlignmentSessions",
    "requirementAlignmentRounds",
    "requirementQuestions",
    "requirementAssumptions",
    "requirementChangeRequests",
  ] as const) {
    if (document[table] === undefined) document[table] = [];
  }
  return document as unknown as AutomationDocument;
}

function upgradeV3ToV4(value: AutomationDocument, repairLegacyPlanBindings = false): AutomationDocument {
  const document = structuredClone(value) as AutomationDocument;
  const origins = Array.isArray(document.requirementOrigins) ? document.requirementOrigins : [];
  const byId = new Map(origins.map((origin) => [origin.requirementOriginId, origin]));
  for (const requirement of document.requirementVersions) {
    const sourceOriginRef = typeof requirement.originRef === "string" && requirement.originRef.length > 0 && requirement.originRef.length <= 256 && !/^https?:\/\//i.test(requirement.originRef)
      ? requirement.originRef
      : null;
    if (!sourceOriginRef || !byId.has(sourceOriginRef)) {
      const requirementOriginId = sourceOriginRef ?? `legacy-origin:${requirement.projectId}:${requirement.requirementVersionId}`;
      const origin = {
        requirementOriginId,
        projectId: requirement.projectId,
        originType: "IMPORT" as const,
        source: "SYSTEM" as const,
        sourceRef: null,
        createdAt: requirement.createdAt,
      };
      if (!byId.has(requirementOriginId)) {
        origins.push(origin);
        byId.set(requirementOriginId, origin);
      }
      requirement.originRef = requirementOriginId;
    } else {
      requirement.originRef = sourceOriginRef;
    }
  }
  document.requirementOrigins = origins;
  // K1-A is an additive extension of the v4 document. Legacy stage/step
  // rows are materialized with bounded defaults while their existing IDs,
  // references, goals, and version lineage remain unchanged.
  document.stageSpecs = document.stageSpecs.map((value) => {
    const item = { ...(value as unknown as Record<string, unknown>) };
    const objective = typeof item.objective === "string" && item.objective.length > 0
      ? item.objective
      : typeof item.goal === "string" && item.goal.length > 0
        ? item.goal
        : "legacy stage objective";
    item.name = typeof item.name === "string" && item.name.length > 0 ? item.name : String(item.stageKey ?? item.stageSpecId);
    item.objective = objective;
    item.goal = objective;
    item.dependsOn = Array.isArray(item.dependsOn) ? item.dependsOn : [];
    item.acceptanceCriteria = Array.isArray(item.acceptanceCriteria) ? item.acceptanceCriteria : [];
    item.detailLevel = item.detailLevel === "DETAILED" ? "DETAILED" : "OUTLINE";
    item.assumptions = Array.isArray(item.assumptions) ? item.assumptions : [];
    item.risks = Array.isArray(item.risks) ? item.risks : [];
    return item as unknown as AutomationDocument["stageSpecs"][number];
  });
  const nextStepOrdinalByStage = new Map<string, number>();
  document.stepSpecs = document.stepSpecs.map((value) => {
    const item = { ...(value as unknown as Record<string, unknown>) };
    const objective = typeof item.objective === "string" && item.objective.length > 0
      ? item.objective
      : typeof item.goal === "string" && item.goal.length > 0
        ? item.goal
        : "legacy step objective";
    item.objective = objective;
    item.goal = objective;
    item.inputs = Array.isArray(item.inputs) ? item.inputs : [];
    item.expectedOutputs = Array.isArray(item.expectedOutputs) ? item.expectedOutputs : [];
    item.acceptanceCriteria = Array.isArray(item.acceptanceCriteria) ? item.acceptanceCriteria : [];
    item.assumptions = Array.isArray(item.assumptions) ? item.assumptions : [];
    item.constraints = Array.isArray(item.constraints) ? item.constraints : [];
    const stageKey = String(item.stageSpecId ?? "legacy-stage");
    if (item.ordinal === undefined) item.ordinal = (nextStepOrdinalByStage.get(stageKey) ?? 0) + 1;
    if (typeof item.ordinal === "number" && Number.isSafeInteger(item.ordinal) && item.ordinal >= 0) {
      nextStepOrdinalByStage.set(stageKey, Math.max(nextStepOrdinalByStage.get(stageKey) ?? 0, item.ordinal));
    }
    return item as unknown as AutomationDocument["stepSpecs"][number];
  });
  // K1-D redesign is additive: old ActionIntent/ActionAttempt rows keep their
  // original IDs, timestamps, receipts, and provider refs while Planner rows
  // gain a logical-request projection and per-attempt classification defaults.
  const plannerIntents = new Map<string, Record<string, unknown>>();
  document.actionIntents = document.actionIntents.map((value) => {
    const item = { ...(value as unknown as Record<string, unknown>) };
    if (item.actionType !== "PLANNER_REQUEST") return item as unknown as AutomationDocument["actionIntents"][number];
    const options = item.executionOptions && typeof item.executionOptions === "object" && !Array.isArray(item.executionOptions)
      ? item.executionOptions as Record<string, unknown>
      : {};
    item.logicalPlannerRequestId = typeof item.logicalPlannerRequestId === "string" && item.logicalPlannerRequestId.length > 0 ? item.logicalPlannerRequestId : item.intentId;
    item.plannerRequirementVersionId = typeof item.plannerRequirementVersionId === "string" ? item.plannerRequirementVersionId : typeof options.requirementVersionId === "string" ? options.requirementVersionId : null;
    item.plannerRequirementPayloadSha256 = typeof item.plannerRequirementPayloadSha256 === "string" ? item.plannerRequirementPayloadSha256 : typeof options.requirementPayloadSha256 === "string" ? options.requirementPayloadSha256 : null;
    item.plannerOperation = item.plannerOperation === "PLAN_REQUIREMENT" || item.plannerOperation === "DETAIL_STAGE"
      ? item.plannerOperation
      : options.plannerOperation === "PLAN_REQUIREMENT" || options.plannerOperation === "DETAIL_STAGE" ? options.plannerOperation : null;
    item.plannerMaxProviderAttempts = item.plannerMaxProviderAttempts === 2 ? 2 : 2;
    item.promotedPlanVersionId = typeof item.promotedPlanVersionId === "string" ? item.promotedPlanVersionId : null;
    item.plannerState = item.plannerState === "REQUESTED" || item.plannerState === "ACTIVE" || item.plannerState === "VALIDATED" || item.plannerState === "PROMOTED" || item.plannerState === "FAILED"
      ? item.plannerState
      : item.promotedPlanVersionId ? "PROMOTED" : item.state === "FAILED" ? "FAILED" : item.state === "PLANNED" ? "REQUESTED" : "ACTIVE";
    plannerIntents.set(String(item.intentId), item);
    return item as unknown as AutomationDocument["actionIntents"][number];
  });
  document.actionAttempts = document.actionAttempts.map((value) => {
    const item = { ...(value as unknown as Record<string, unknown>) };
    const intent = plannerIntents.get(String(item.intentId));
    if (!intent) return item as unknown as AutomationDocument["actionAttempts"][number];
    item.createdAt = typeof item.createdAt === "string" ? item.createdAt : intent.createdAt;
    item.logicalPlannerRequestId = typeof item.logicalPlannerRequestId === "string" && item.logicalPlannerRequestId.length > 0 ? item.logicalPlannerRequestId : intent.logicalPlannerRequestId;
    item.attemptNumber = typeof item.attemptNumber === "number" ? item.attemptNumber : item.dispatchNumber;
    item.providerTargetRef = typeof item.providerTargetRef === "string" ? item.providerTargetRef : intent.targetRef ?? null;
    item.plannerResultClassification = item.plannerResultClassification ?? null;
    item.externalSideEffectCertainty = item.externalSideEffectCertainty ?? null;
    return item as unknown as AutomationDocument["actionAttempts"][number];
  });
  const plansById = new Set(document.planVersions.map((plan) => plan.planVersionId));
  for (const event of document.auditEvents) {
    if (event.eventType !== "PLANNER_PLAN_PROMOTED" || !plansById.has(event.entityId)) continue;
    const payload = event.boundedPayload;
    const actionIntentId = typeof payload.actionIntentId === "string" ? payload.actionIntentId : null;
    const logicalId = typeof payload.logicalPlannerRequestId === "string" ? payload.logicalPlannerRequestId : event.correlationId;
    const intent = document.actionIntents.find((candidate) => candidate.actionType === "PLANNER_REQUEST" && (
      (actionIntentId !== null && candidate.intentId === actionIntentId)
      || (logicalId !== null && (candidate.logicalPlannerRequestId ?? candidate.intentId) === logicalId)
    ));
    if (!intent) continue;
    if (intent.promotedPlanVersionId !== null && intent.promotedPlanVersionId !== undefined && intent.promotedPlanVersionId !== event.entityId) {
      throw new AutomationSchemaError("Planner promotion audit evidence conflicts with the persisted promoted PlanVersion.");
    }
    intent.promotedPlanVersionId = event.entityId;
    intent.plannerState = "PROMOTED";
  }
  if (repairLegacyPlanBindings) {
    const requirementsById = new Map(document.requirementVersions.map((requirement) => [requirement.requirementVersionId, requirement]));
    document.planVersions = document.planVersions.map((value) => {
      const item = { ...(value as unknown as Record<string, unknown>) };
      const requirement = requirementsById.get(String(item.requirementVersionId));
      if (requirement) item.requirementPayloadSha256 = requirement.payloadSha256;
      return item as unknown as AutomationDocument["planVersions"][number];
    });
  }
  document.automationSchemaVersion = 4;
  return document;
}

export function migrateAutomationDocument(value: unknown): { document: AutomationDocument; migratedFrom: number | null } {
  const input = record(value);
  const hasAutomationVersion = Object.prototype.hasOwnProperty.call(input, "automationSchemaVersion");
  const hasLegacyVersion = Object.prototype.hasOwnProperty.call(input, "schemaVersion");
  if (hasAutomationVersion && hasLegacyVersion && input.automationSchemaVersion !== input.schemaVersion) throw new AutomationSchemaError("Automation schema version fields conflict.", "AUTOMATION_SCHEMA_VERSION_UNSUPPORTED");
  const versionValue = hasAutomationVersion ? input.automationSchemaVersion : hasLegacyVersion ? input.schemaVersion : undefined;
  if (versionValue === undefined) throw new AutomationSchemaError("Automation schema version is required.", "AUTOMATION_SCHEMA_VERSION_UNSUPPORTED");
  if (typeof versionValue !== "number" || !Number.isSafeInteger(versionValue)) throw new AutomationSchemaError("Automation schema version is invalid.");
  if (versionValue > AUTOMATION_SCHEMA_VERSION) throw new AutomationSchemaError("Automation schema version is newer than this runtime.", "AUTOMATION_SCHEMA_VERSION_UNSUPPORTED");
  if (versionValue === 0) {
    const migrated = upgradeV3ToV4(migrateV0ToV3(input), true);
    return { document: validateAutomationDocument(migrated), migratedFrom: 0 };
  }
  if (versionValue === 1) {
    const migrated = upgradeV3ToV4(migrateV1ToV3(input), true);
    return { document: validateAutomationDocument(migrated), migratedFrom: 1 };
  }
  if (versionValue === 2) {
    const migrated = upgradeV3ToV4(migrateV2ToV3(input), true);
    return { document: validateAutomationDocument(migrated), migratedFrom: 2 };
  }
  if (versionValue === 3) {
    const migrated = upgradeV3ToV4(input as unknown as AutomationDocument, true);
    return { document: validateAutomationDocument(migrated), migratedFrom: 3 };
  }
  const current = hasAutomationVersion ? input : { ...input, automationSchemaVersion: versionValue };
  // Normalize additive K1-A fields for current-schema legacy rows as well.
  // This is in-memory on reads; persistence only changes at an explicit write.
  const normalized = upgradeV3ToV4(current as unknown as AutomationDocument);
  return { document: validateAutomationDocument(normalized), migratedFrom: null };
}

export {
  REQUIREMENT_ALIGNMENT_PROTOCOL,
  REQUIREMENT_MAX_ANSWER_LENGTH,
  REQUIREMENT_MAX_ASSUMPTIONS_PER_ROUND,
  REQUIREMENT_MAX_METADATA_ENTRIES,
  REQUIREMENT_MAX_QUESTIONS_PER_ROUND,
  REQUIREMENT_MAX_ROUNDS_PER_SESSION,
  REQUIREMENT_MAX_TEXT_LENGTH,
  REQUIREMENT_PROTOCOL,
  REQUIREMENT_PROTOCOL_VERSION,
  validateRequirementAlignmentDocument,
  validateRequirementAlignmentRound,
  validateRequirementAlignmentSession,
  validateRequirementAssumption,
  validateRequirementDomain,
  validateRequirementProtocol,
  validateRequirementQuestion,
} from "./requirement-domain.ts";
