export interface StageK1DProvenance {
  readonly source_commit: string | null;
  readonly worktree_state: string | null;
  readonly worktree_state_sha256: string | null;
  readonly source_tree_sha256: string | null;
  readonly build_timestamp: string | null;
  readonly package_timestamp: string | null;
  readonly executable_path: string | null;
  readonly executable_sha256: string | null;
  readonly expected_executable_sha256: string | null;
  readonly runner_script_sha256: string | null;
  readonly expected_runner_script_sha256: string | null;
  readonly evidence_timestamp: string | null;
  readonly verified: boolean;
  readonly verification_errors: readonly string[];
}

export interface StageK1DProvenanceAssessmentInput {
  readonly manifest: Record<string, unknown> | null;
  readonly executablePath: string | null;
  readonly executableSha256: string | null;
  readonly runnerScriptSha256: string | null;
}

function manifestText(manifest: Record<string, unknown> | null, key: string): string | null {
  const value = manifest?.[key];
  return typeof value === "string" && value.trim() ? value.trim() : null;
}

/**
 * Compare runtime facts with the immutable package manifest. Missing or
 * mismatched facts are explicit errors, never a best-effort PASS.
 */
export function assessStageK1DProvenance(input: StageK1DProvenanceAssessmentInput): StageK1DProvenance {
  const errors: string[] = [];
  const source_commit = manifestText(input.manifest, "source_commit");
  const worktree_state = manifestText(input.manifest, "worktree_state");
  const worktree_state_sha256 = manifestText(input.manifest, "worktree_state_sha256");
  const source_tree_sha256 = manifestText(input.manifest, "source_tree_sha256");
  const build_timestamp = manifestText(input.manifest, "build_timestamp");
  const package_timestamp = manifestText(input.manifest, "package_timestamp");
  const expected_executable_sha256 = manifestText(input.manifest, "executable_sha256");
  const expected_runner_script_sha256 = manifestText(input.manifest, "runner_script_sha256");
  if (!input.manifest) errors.push("PACKAGE_PROVENANCE_MANIFEST_MISSING");
  if (!source_commit) errors.push("SOURCE_COMMIT_MISSING");
  if (!worktree_state || !worktree_state_sha256) errors.push("WORKTREE_PROVENANCE_MISSING");
  if (!source_tree_sha256) errors.push("SOURCE_TREE_HASH_MISSING");
  if (!build_timestamp) errors.push("BUILD_TIMESTAMP_MISSING");
  if (!package_timestamp) errors.push("PACKAGE_TIMESTAMP_MISSING");
  if (!expected_executable_sha256) errors.push("EXPECTED_EXECUTABLE_HASH_MISSING");
  if (!expected_runner_script_sha256) errors.push("EXPECTED_RUNNER_HASH_MISSING");
  if (!input.executableSha256) errors.push("EXECUTABLE_HASH_UNAVAILABLE");
  if (!input.runnerScriptSha256) errors.push("RUNNER_HASH_NOT_SUPPLIED");
  if (expected_executable_sha256 && input.executableSha256 !== expected_executable_sha256) errors.push("EXECUTABLE_HASH_MISMATCH");
  if (expected_runner_script_sha256 && input.runnerScriptSha256 && expected_runner_script_sha256 !== input.runnerScriptSha256) errors.push("RUNNER_HASH_MISMATCH");
  return {
    source_commit,
    worktree_state,
    worktree_state_sha256,
    source_tree_sha256,
    build_timestamp,
    package_timestamp,
    executable_path: input.executablePath,
    executable_sha256: input.executableSha256,
    expected_executable_sha256,
    runner_script_sha256: input.runnerScriptSha256,
    expected_runner_script_sha256,
    evidence_timestamp: null,
    verified: errors.length === 0,
    verification_errors: errors,
  };
}
