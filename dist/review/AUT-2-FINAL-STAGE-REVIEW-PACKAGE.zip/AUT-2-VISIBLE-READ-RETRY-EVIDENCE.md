# AUT-2 Follow-up Visible Read Retry Evidence

## Scope

本文件记录用户要求“显示实际操作”后，对既有 `workts / REQUIREMENT` 测试 Chat 执行的只读跟进。没有发送 Prompt、创建 Chat、替换 Role binding，也没有读取 Cookie、Token 或聊天正文。

目标 Chat：

`https://chatgpt.com/g/g-6a85db5dd9c4819181028671e2fb9315-workts/c/6a88873d-0af0-83e8-a2e7-202adf2560f8`

## 操作结果

| 序号 | 操作 | 结果 | 关键证据 |
|---:|---|---|---|
| 5 | `chat latest --url <target> --json` | FAIL | `23f3e745-6ef0-44a6-a2f5-f387c79966d2` → `TARGET_CHAT_MISMATCH` |
| 6 | `open-chat --url <target> --json` | PASS | `4587dce3-b33d-44cd-abdf-08355b31d017`，URL 匹配、已登录、Chat 页面、Composer 存在 |
| 7 | `chat latest --url <target> --json` | FAIL | `00f042d5-93a5-41ee-9e17-977bedafb884` → `TARGET_CHAT_MISMATCH` |
| 8 | `open-chat --url <target> --json` | PASS | `945ca486-2940-4e0b-98c0-b93b66995388`，URL 匹配、已登录、Chat 页面、Composer 存在 |
| 9 | `chat latest --url <target> --json` | FAIL | `baa44d7e-ba2b-45dc-90b1-9927f6c81dda` → `TARGET_CHAT_MISMATCH` |

两次可见 `open-chat` 均返回：

```yaml
url_matches_target: true
login_required: false
on_chat_page: true
composer_found: true
generating: false
user_count: 0
assistant_count: 0
```

但随后 `chat latest` 的读取结果身份校验仍失败，控制面只返回：

```yaml
code: TARGET_CHAT_MISMATCH
retryable: false
userAction: reopen_target_chat
```

## 结论

- 本轮新增只读读取：3 次；全部 `TARGET_CHAT_MISMATCH`。
- Fix5 基线 4 次 + 本轮 3 次 = 累计 7 次 exact read 失败。
- `open-chat` 的页面导航成功不等于 `chat latest` 的结果身份读取成功。
- 失败后保持 fail-closed：没有读取或返回可能属于其他 Chat 的内容。
- 原 REQUIREMENT binding 未改变，没有创建替代 Chat。
- 本轮没有消耗真实 Prompt、repair Prompt、setup Prompt 或新 Chat 预算。

因此 AUT-2 仍为 `FIX_REQUIRED / BLOCKED`，不能进入 AUT-3。下一步若继续，应先做只读的实际 readback identity 取证；不能删除身份校验、静默 rebind 或发送 Prompt 绕过。
