# ARCH-V2-5 GPT Review Handoff

请审查 `ARCH-V2-5-STAGE-REVIEW.md` 及同目录 supporting evidence。

重点问题：

- `EffectivePolicy` 是否正确实现 HardConstraints ∩ PolicyVersion ∩ RuntimeCapability；
- persisted `PolicyVersion` 是否仍是唯一策略事实源；
- pin 是否覆盖 project/version/correlation 并在 drift 时 fail closed；
- 四类预算是否应在下一轮切换全部生产业务入口；
- legacy unpinned record 的兼容/拒绝策略是否可接受；
- 本阶段是否保持 V1 Frozen Core、AUT-2/AUT-3 和 WebGPT 业务边界未被扩大。

本地 gate 是 `REVIEW_READY_WITH_DISCLOSED_LIMITATIONS`，不是自动宣布后续阶段通过。

## FIX ROUND 1 GPT finding

上一轮 GPT Gate 返回 FIX_REQUIRED，范围为：

- FIX-01：枚举并闭合全部生产 Budget callers；
- FIX-02：PROMPT/RETRY/NEW_CHAT production consumer evidence；
- FIX-03：legacy unpinned mutation fail-closed；
- P2：reserve/commit/abort-before-dispatch lifecycle。

本轮实现和证据见：

- ARCH-V2-5-FIX-ROUND-1.md
- ARCH-V2-5-BUDGET-CALLER-INVENTORY.md
- ARCH-V2-5-PRODUCTION-BUDGET-CONSUMERS.md
- ARCH-V2-5-LEGACY-UNPINNED-EVIDENCE.md
- ARCH-V2-5-RESERVATION-LIFECYCLE.md

当前状态为 READY_FOR_GPT_REVIEW，不是本地自宣称 PASS。

## FIX ROUND 2 submission

最新 GPT Gate：`FIX_REQUIRED`，P0=0、P1=2、P2=1。P1 要求是：

1. 默认 `npm test` 不得收集历史 review staging 测试副本；
2. packaged WEB-6.6 `webgpt.status` 必须有真实启动/readiness/CLI 证据和
   有界确定性 JSON。

本轮已按最小范围修复并复测：`npm test` 为 336/336；隔离 packaged Workbench
保持运行并通过同一 Control Plane 完成 `initialize -> webgpt.status`，随后用
打包内 CLI Runtime 的 official CLI ABI 对同一 descriptor 再读一次 status，均为
`exitCode=0`、`ok=true`。完整结果见 `ARCH-V2-5-FIX-ROUND-2.md`。

```yaml
fix_round_2_commit: d445fb5
new_real_prompts: 0
v1_core_changed: NO
aut2_aut3_activated: NO
next_action: USER_SUBMIT_REVIEW_TO_GPT
```
